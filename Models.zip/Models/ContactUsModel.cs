﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BC.Models
{
    public class ContactUsModel : ContactU
    {
        [Required(ErrorMessage="Enter your Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use letters only please")]
        public string Name { get; set; }

        [Required(ErrorMessage="Enter your Email Address")]
        public string EmailId { get; set; }

        [Required(ErrorMessage="Enter your Message")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use letters only please")]
        public string Message { get; set; }
        
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString="{0:dd/MMM/yyyy}", ApplyFormatInEditMode=true)]
        public Nullable<System.DateTime> DateTime { get; set; }
    }
}