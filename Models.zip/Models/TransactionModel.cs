﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BC.Models
{
    public class TransactionModel : TransactionTable
    {
        public int AddId { get; set; }
        public int BookId { get; set; }
        public int TransactionId { get; set; }
        public string ImageUrl { get; set; }
        public string Name { get; set; }
        public string AuthorName { get; set; }
        public int BookCost { get; set; }
        public string StatusName { get; set; }
        public string FullName { get; set; }
        public string Address { get; set; }
        public string PinCode { get; set; }
        public string Mobile { get; set; }
        public List<SelectListItem> DeliveryStatus { get; set; }

        public List<SelectListItem> Transaction { get; set; }

        public List<TransactionModel> TransactionList { get; set; }
    }
}