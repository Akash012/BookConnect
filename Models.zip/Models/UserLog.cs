﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BC.Models
{
    public class UserLog : UserDetailLog
    {
        [Required]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime ActionDate { get; set; }

        //public IEnumerable<UserDetailLog> UserLogList { get; set; }

        public List<UserDetailLog> UserDetailList { get; set; }
    }
}