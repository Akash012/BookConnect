﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BC.Models
{
    public class UserModel : UserDetail
    {
        [Required(ErrorMessage = "Enter Full Name")]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Enter Full Address")]
        [Display(Name = "Full Address")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Enter Date Of Birth")]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Date Of Birth")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Enter Mobile Number")]
        [Display(Name = "Mobile Number")]
        [StringLength(10, ErrorMessage = "The Mobile must contain 10 characters", MinimumLength = 10)]
        public string MobileNo { get; set; }

        [Required(ErrorMessage = "Enter Pin Code")]
        [StringLength(6, ErrorMessage = "The Pin Code must contain 06 characters", MinimumLength = 6)]
        [Display(Name = "Pin Code")]
        public string PinCode { get; set; }

        public string Email { get; set; }

        public string UserName { get; set; }

        public string Gender { get; set; }
    }
}