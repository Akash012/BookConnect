﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BC.Models
{
    public class BookModel : BookTable
    {
        //public int ID { get; set; }
        //[Required]
        [Display(Name = "Image Url")]
        public string ImageUrl { get; set; }

        //[Required]
        [Display(Name = "Book Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use letters only please")]
        public string Name { get; set; }
        //public string ImageUrl { get; set; }
        public List<SelectListItem> Category { get; set; }
        //[Required]
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }

        //[Required]
        [Display(Name="Book Description")]
        public string BookDescription { get; set; }

        //[Required]
        [Display(Name="Author Name")]
        public string AuthorName { get; set; }

        [RegularExpression(@"^([0-9])$", ErrorMessage = "Quantity should be digit only.")]
        public int Quantity { get; set; }
        [Display(Name = "Available Quantity")]
        public int AvailableQuantity { get; set; }
        [Display(Name = "Issue Quantity")]
        public int IssuedQuantity { get; set; }
        [Display(Name = "Boom Cost")]
        public int BookCost { get; set; }
        [Display(Name = "Boom Status")]
        public string BookStatus { get; set; }
        public IEnumerable<BookTable> BookTableList { get; set; }
        public List<SelectListItem> AvailableQuantityList { get; set; }
    }
}