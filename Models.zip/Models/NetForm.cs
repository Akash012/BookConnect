﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BC.Models
{
    public class NetForm
    {
        [Required]
        [Display(Name = "Transaction ID")]
        [RegularExpression(@"^([0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])$", ErrorMessage = "Transaction ID should be 10 digit and digit only.")]
        [StringLength(10, ErrorMessage = "The Transaction ID must contain 10 characters", MinimumLength = 10)]
        public String TransactionId { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public String Password { get; set; }
    }
}