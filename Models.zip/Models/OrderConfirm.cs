﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BC.Models
{
    public class OrderConfirm
    {
        
        public int OrderId { get; set; }
        public int CartId { get; set; }
        public string BookName { get; set; }
        public int BookCost { get; set; }
        public string AuthorName { get; set; }
        public int ID { get; set; }
        public int NoOfQuantity { get; set; }
        public int TotalCost { get; set; }
    }
}