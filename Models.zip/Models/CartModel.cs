﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace BC.Models
{
    public class CartModel : CartTable
    {
        
        public int CartId { get; set; }

        public string UserName { get; set; }
        public int ID { get; set; }
        public int NoOfQuantity { get; set; }
        public int StatusId { get; set; }

        public string ImageUrl { get; set; }
        public string Name { get; set; }
        public string AuthorName { get; set; }
        public int BookCost { get; set; }
        public int AvailableQuantity { get; set; }
        public int TotalCost { get; set; }
        public int FinalCost { get; set; }

        
        public List<SelectListItem> AvailableQuantityList { get; set; }

       
    }
}