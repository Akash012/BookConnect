﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace BC.Models
{
    public class LogOnModel
    {
        //[Required]
        //[Display(Name = "Select Location")]
        //public string Location { get; set; }

        //public IEnumerable<SelectListItem> Locations { get; set; }

        [Required]
        [Display(Name = "User name")]
        public string MOBILEALIAS { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }

      
    }

    public class RegisterModel
    {
        [Required(ErrorMessage="Enter User Name")]
        [Display(Name = "User name")]
        public string UserName { get; set; }

        [Required(ErrorMessage="Enter Email Address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        public string Email { get; set; }

        [Required(ErrorMessage="Enter Password")]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage="Enter Full Name")]
        [Display(Name = "Name")]
        [RegularExpression(@"^[a-zA-Z]*$", ErrorMessage = "Please use letters only")]
        public string FullName { get; set; }

        [Required (ErrorMessage="Enter Full Address")]
        [Display(Name="Full Address")]
        public string Address { get; set; }

        [Required(ErrorMessage= "Enter Date Of Birth")]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Date Of Birth")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage="Enter Mobile Number")]
        [Display(Name ="Mobile Number")]
        [StringLength(10, ErrorMessage = "The Mobile must contain 10 characters", MinimumLength = 10)]
        public string MobileNo { get; set; }

        [Required(ErrorMessage = "Enter Pin Code")]
        [StringLength(6, ErrorMessage = "The Pin Code must contain 06 characters", MinimumLength = 6)]
        [Display(Name="Pin Code")]
        public string PinCode{get; set;}

        [Required(ErrorMessage = "Enter Your Gender")]
        [Display(Name = "Gender")]
        public string Gender { get; set; }
    }

    public class ChangePasswordModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

   public class ConfirmUser
   {
       [Required]
       [Display(Name = "Email ID")]
       public string EmailId { get; set; }

   }

    public class ForgetPassword
    {
        [Required]
       [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
       [DataType(DataType.Password)]
       [Display(Name = "New password")]
       public string NewPassword { get; set; }

       [DataType(DataType.Password)]
       [Display(Name = "Confirm new password")]
       [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
       public string ConfirmPassword { get; set; }
    }
}