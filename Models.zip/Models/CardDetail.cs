﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BC.Models
{
    public class CardDetail
    {
        [Required(ErrorMessage="Enter Card Number")]
        [Display(Name="Card Number")]
        [RegularExpression(@"^([0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])$", ErrorMessage = "Card Number should be 16 digit and digit only.")]
        [StringLength(16,ErrorMessage="Card Number should be 16 digit.",MinimumLength=16)]
        public string CardNo { get; set; }
        
        [Required(ErrorMessage="Enter CVV Number")]
        [RegularExpression(@"^([0-9][0-9][0-9])$", ErrorMessage = "CVV Number should be 3 digit and digit only.")]
        [StringLength(3, ErrorMessage = "CVV should be 3 digit", MinimumLength = 3)]
        public string CVV { get; set; }
        
        [StringLength(2, ErrorMessage = "Month should be 2 digit", MinimumLength = 2)]
        [DisplayFormat(DataFormatString = "{0:MM}", ApplyFormatInEditMode = true)]
        public string Month { get; set; }

        [StringLength(4, ErrorMessage = "Year should be 4 digit", MinimumLength = 4)]
        [DisplayFormat(DataFormatString = "{0:yyyy}", ApplyFormatInEditMode = true)]
        public string Year { get; set; }

        [Display(Name="Card Holder Name")]
        public string CardName { get; set; }
    }
}