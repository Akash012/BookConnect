﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace BC.Models
{
    public class NetBank
    {
        [Required]
        public string Bank { get; set; }
    }
}