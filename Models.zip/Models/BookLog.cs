﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BC.Models
{
    public class BookLog : BooksLog
    {
        [Display(Name="Audit Id")]
        public int AuditId { get; set; }

        public List<BookTable> Booktable { get; set; }
        [Required]
        [Display(Name = "Book Name")]
        public string BookName { get; set; }

        public List<BookStatu> BookStatus { get; set; }
        [Required]
        [Display(Name = "Action Type")]
        public string ActionType { get; set; }

        [Required]
        [Display(Name = "Action Date")]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime ActionDate { get; set; }

        public IEnumerable<BooksLog> BookLogList { get; set; }

        //public string OldName { get; set; }
        //public string NewName { get; set; }
        public List<Category> Category { get; set; }
        [Display(Name = "Old Category Name")]
        public string OldCategoryName { get; set; }
        [Display(Name = "New Category Name")]
        public string NewCategoryName { get; set; }
        [Display(Name = "Old Author Name")]
        public string OldAuthorName { get; set; }
        [Display(Name = "New Author Name")]
        public string NewAuthorName { get; set; }
        [Display(Name = "Old Book Description")]
        public string OldBookDescription { get; set; }
        [Display(Name = "New Book Description")]
        public string NewBookDescription { get; set; }
        [Display(Name = "Old Issue Quantity")]
        public Nullable<int> OldIssueQuantity { get; set; }
        [Display(Name = "New Issue Quantity")]
        public Nullable<int> NewIssueQuantity { get; set; }
        [Display(Name = "Old Book Cost")]
        public Nullable<int> OldBookCost { get; set; }
        [Display(Name = "New Book Cost")]
        public Nullable<int> NewBookCost { get; set; }
        [Display(Name = "Old Quantity")]
        public Nullable<int> OldQuantity { get; set; }
        [Display(Name = "New Quantity")]
        public Nullable<int> NewQuantity { get; set; }
        [Display(Name = "Old Available Quantity")]
        public Nullable<int> OldAvailableQuantity { get; set; }
        [Display(Name = "New Available Quantity")]
        public Nullable<int> NewAvailableQuantity { get; set; }
       
    }
}