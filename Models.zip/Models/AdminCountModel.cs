﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BC.Models
{
    public class AdminCountModel
    {
        public int POrder { get; set; }
        public int DOrder { get; set; }
        public int Reg { get; set; }
        public int Popular { get; set; }
    }
}