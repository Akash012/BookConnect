﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;

namespace BC.Controllers
{
    public class UserManageController : Controller
    {
        private UserDBEntities db = new UserDBEntities();

        //
        // GET: /UserManage/

        public ActionResult Index()
        {
            List<RegisterModel> regmodel = new List<RegisterModel>();
            var user = (from a in db.UserDetails
                        where (a.UserName == User.Identity.Name
                        && (a.StatusId == 1 || a.StatusId == 3))
                        select a).ToList();
            foreach (var d in user)
            {
                RegisterModel pm = new RegisterModel();
                pm.FullName = d.FullName;
                pm.Address = d.Address;
                pm.PinCode = d.PinCode;
                pm.MobileNo = d.MobileNo;
                pm.Email = d.EmailId;
                regmodel.Add(pm);
            }
            return View(user.ToList());
        }

        //
        // GET: /Order/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Order/Create

        [HttpPost]
        public ActionResult Create(UserDetail userdetail, FormCollection fc)
        {
            if (!string.IsNullOrEmpty(fc["FullName"]) && !string.IsNullOrEmpty(fc["Address"])
                && !string.IsNullOrEmpty(fc["PinCode"]) && !string.IsNullOrEmpty(fc["MobileNo"]) && !string.IsNullOrEmpty(fc["Gender"]))
            {
                var usr = (from a in db.UserDetails
                           where a.UserName == User.Identity.Name
                           select a.EmailId).FirstOrDefault();
                userdetail.EmailId = usr;
                userdetail.UserName = User.Identity.Name;
                userdetail.StatusId = 1;
                userdetail.Gender = (fc["Gender"]);
                UserDetail users = (from user in db.UserDetails
                                    where user.MobileNo == userdetail.MobileNo
                                    select user).FirstOrDefault();
                if (users == null)
                {
                    userdetail.MobileNo = fc["MobileNo"].ToString();
                }
                else
                {
                    ModelState.AddModelError("", "Mobile Number is already exist");
                }
                if (ModelState.IsValid)
                {
                    UserDetailLog userlog = new UserDetailLog();
                    db.UserDetails.Add(userdetail);
                    db.SaveChanges();
                    userlog.UserName = userdetail.UserName;
                    userlog.Gender = userdetail.Gender;
                    userlog.ActionType = "Added";
                    userlog.ActionDate = System.DateTime.Now;
                    userlog.NewFullName = userdetail.FullName;
                    userlog.EmailId = userdetail.EmailId;
                    userlog.NewAddress = userdetail.Address;
                    userlog.NewPinCode = userdetail.PinCode;
                    userlog.NewMobileNo = userdetail.MobileNo;
                    db.UserDetailLogs.Add(userlog);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(userdetail);
            }
            else
            {
                ModelState.AddModelError("", "Please Fill all requried field");
                return View();
            }
        }

        //
        // GET: /Order/Edit/5

        public ActionResult Edit(int id = 0)
        {
            UserDetail userdetail = db.UserDetails.Find(id);
            HttpContext.Session.Add("OldData", userdetail);
            if (userdetail == null)
            {
                return HttpNotFound();
            }
            return View(userdetail);
        }

        //
        // POST: /Order/Edit/5

        [HttpPost]
        public ActionResult Edit(UserDetail userdetail, FormCollection fc)
        {
            if (!string.IsNullOrEmpty(fc["FullName"]) && !string.IsNullOrEmpty(fc["Address"])
               && !string.IsNullOrEmpty(fc["PinCode"]) && !string.IsNullOrEmpty(fc["MobileNo"]))
            {
                UserDetailLog userlog = new UserDetailLog();
                UserDetail oldlist = Session["OldData"] as UserDetail;
                userdetail.Gender = oldlist.Gender;
                userdetail.EmailId = oldlist.EmailId;
                userdetail.UserName = User.Identity.Name;
                userdetail.StatusId = 3;
                UserDetail users = (from user in db.UserDetails
                                    where user.MobileNo == userdetail.MobileNo
                                    select user).FirstOrDefault();
                if (users == null)
                {
                    userdetail.MobileNo = fc["MobileNo"].ToString();
                }
                else
                {
                    ModelState.AddModelError("", "Mobile Number is already exist");
                }
                if (ModelState.IsValid)
                {
                    db.Entry(userdetail).State = EntityState.Modified;
                    db.SaveChanges();
                    bool IsEdited = false;
                    userlog.UserName = userdetail.UserName;
                    userlog.ActionType = "Edited";
                    userlog.ActionDate = System.DateTime.Now;
                    userlog.EmailId = userdetail.EmailId;
                    userlog.Gender = userdetail.Gender;
                    if (userdetail.FullName == oldlist.FullName)
                    {
                        userlog.NewFullName = "NAN";
                        userlog.OldFullName = oldlist.FullName;
                    }
                    else
                    {
                        userlog.NewFullName = userdetail.FullName;
                        userlog.OldFullName = oldlist.FullName;
                        IsEdited = true;
                    }
                    if (userdetail.Address == oldlist.Address)
                    {
                        userlog.NewAddress = "NAN";
                        userlog.OldAddress = oldlist.Address;
                    }
                    else
                    {
                        userlog.NewAddress = userdetail.Address;
                        userlog.OldAddress = oldlist.Address;
                        IsEdited = true;
                    }
                    if (userdetail.PinCode == oldlist.PinCode)
                    {
                        userlog.NewPinCode = "NAN";
                        userlog.OldPinCode = oldlist.PinCode;
                    }
                    else
                    {
                        userlog.NewPinCode = userdetail.PinCode;
                        userlog.OldPinCode = oldlist.PinCode;
                        IsEdited = true;
                    }
                    if (userdetail.MobileNo == oldlist.MobileNo)
                    {
                        userlog.NewMobileNo = "NAN";
                        userlog.OldMobileNo = oldlist.MobileNo;
                    }
                    else
                    {
                        userlog.NewMobileNo = userdetail.MobileNo;
                        userlog.OldMobileNo = oldlist.MobileNo;
                        IsEdited = true;
                    }
                    if (IsEdited == true)
                    {
                        db.UserDetailLogs.Add(userlog);
                        db.Entry(userlog).State = EntityState.Added;
                        db.SaveChanges();

                        HttpContext.Session.Add("Message", "Data save sucessfully");

                    }
                    else
                    {

                        HttpContext.Session.Add("Message", "Changes not saved");
                    }
                    HttpContext.Session.Remove("OldData");
                    return RedirectToAction("Index");
                }
                return View(userdetail);
            }
            else
            {
                ModelState.AddModelError("", "Please Fill all requried field");
                return View();
            }
        }

        //
        // GET: /Order/Delete/5

        public ActionResult Delete(int id = 0)
        {
            UserDetail userdetail = db.UserDetails.Find(id);
            HttpContext.Session.Add("OldData", userdetail);
            if (userdetail == null)
            {
                return HttpNotFound();
            }
            return View(userdetail);
        }

        //
        // POST: /Order/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            UserDetailLog userlist = new UserDetailLog();
            UserDetail userdetail = db.UserDetails.Find(id);
            UserDetail oldlist = Session["OldData"] as UserDetail;
            userdetail.UserName = User.Identity.Name;
            userdetail.StatusId = 2;
            //db.UserDetails.Remove(userdetail);
            userlist.UserName = userdetail.UserName;
            userlist.ActionType = "Deleted";
            userlist.ActionDate = System.DateTime.Now;
            userdetail.EmailId = oldlist.EmailId;
            userlist.Gender = oldlist.Gender;
            userlist.NewFullName = oldlist.FullName;
            userlist.NewAddress = oldlist.Address;
            userlist.NewPinCode = oldlist.PinCode;
            userlist.NewMobileNo = oldlist.MobileNo;
            db.UserDetailLogs.Add(userlist);

            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}