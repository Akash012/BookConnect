﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using CaptchaMvc.HtmlHelpers;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Net.Configuration;



namespace BC.Controllers
{
    public class AccountController : Controller
    {
        UserDBEntities db = new UserDBEntities();
        //
        // GET: /Account/

        //string constr = ConfigurationManager.ConnectionStrings["samsungsqlexpress"].ConnectionString;

        public ActionResult LogOn()
        {
            //using (SqlConnection con = new SqlConnection(constr))
            //{
            //    con.Open();
            //    con.Close();
            //}

            return View();
        }

        [HttpPost]
        
        public ActionResult LogOn(LogOnModel sp, string returnUrl)
        {
            Session.Add("LoginUserID", sp.MOBILEALIAS);

            if (ModelState.IsValid)
            {
                //if (!IsUserExistsInEntity(sp.MOBILEALIAS, sp.Location))
                //{
                //    ModelState.AddModelError("", "User Id does not exist for the currently selected location");
                //    sp = BindEntityScreenModel(sp);
                //}
                //else
                {
                    #region
                    using (UserDBEntities entities = new UserDBEntities())
                    {
                        aspnet_Users users = (from user in entities.aspnet_Users
                                              where user.UserName == sp.MOBILEALIAS
                                              select user).FirstOrDefault();
                       
                        if (users == null)
                        {
                            ModelState.AddModelError("", "Enter Your user Id");
                        }
                        else
                        {
                            aspnet_Membership usermember = (from user in entities.aspnet_Membership
                                                            where user.UserId == users.UserId
                                                            select user).FirstOrDefault();

                            if (Membership.ValidateUser(users.UserName, sp.Password))
                            {
                                
                                HttpContext.Session.Add("CurrentUser", users.UserName);
                                //HttpContext.Session.Add("Username", users.UserName);
                                FormsAuthentication.RedirectFromLoginPage(users.UserName, false);
                                int id = 0;
                                var bookid = Session["refe"] as BookTable;
                                if (bookid == null)
                                {
                                    if (users.UserName == "Admin")
                                    {
                                        return RedirectToAction("Index", "Admin");
                                    }
                                    else
                                    {
                                        return RedirectToAction("Index", "Home");
                                    }
                                }
                                else
                                {
                                    //var bookid = Session["refe"] as BookTable;
                                    id = bookid.ID;
                                    return RedirectToAction("Detail", "Books");
                                }
                            }
                        }

                    }
                    #endregion
                }
                
            }
            return View();
        }

       
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(RegisterModel model, FormCollection fc)
        {
            UserDetail userdetail = new UserDetail();
            if (this.IsCaptchaValid("Captcha is not valid"))
            {
                userdetail.FullName = fc["FullName"].ToString();
                userdetail.UserName = fc["UserName"].ToString();
                userdetail.Address = fc["Address"].ToString();
                userdetail.DOB = Convert.ToDateTime(fc["DOB"]);
                userdetail.MobileNo = (fc["MobileNo"]).ToString();
                userdetail.PinCode = (fc["PinCode"]).ToString();
                userdetail.Gender = (fc["Gender"]).ToString();
                userdetail.EmailId = (fc["Email"]).ToString();
                userdetail.StatusId = 1;
                Session["regemail"] = userdetail.EmailId;
                if (!string.IsNullOrEmpty(fc["UserName"]) || !string.IsNullOrWhiteSpace(fc["UserName"]))
                {
                if (ModelState.IsValid)
                {
                   
                   var email = (from a in db.UserDetails select a).ToList();
                   //var mobile = (from q in db.UserDetails select q.MobileNo).ToList();
                   //var username = (from w in db.UserDetails select w.UserName).ToList();
                    if(email != null)
                    {
                   foreach (var b in email)
                   { 
                   if (b.EmailId == (fc["Email"]) || b.MobileNo == (fc["MobileNo"]) || b.UserName == (fc["UserName"]))
                   {
                       if (b.EmailId == (fc["Email"]))
                       {
                           ViewBag.Message = "EmailID is already exits.";
                           return View();
                       }
                       else if (b.MobileNo == (fc["MobileNo"]))
                       {
                           ViewBag.msg = "Mobile Number is already exits.";
                           return View();
                       }
                       else
                       {
                           ViewBag.ms = "User Name is already exits.";
                           return View();
                            
                       }
                   }
                   }
                    }
                 
                       // Attempt to register the user
                       MembershipCreateStatus createStatus;
                       Membership.CreateUser(model.UserName, model.Password, model.Email, null, null, true, null, out createStatus);
                   
                       UserDetailLog userlog = new UserDetailLog();
                       db.UserDetails.Add(userdetail);
                       db.SaveChanges();
                       userlog.UserName = userdetail.UserName;
                       userlog.Gender = userdetail.Gender;
                       userlog.ActionType = "Added";
                       userlog.ActionDate = System.DateTime.Now;
                       userlog.NewFullName = userdetail.FullName;
                       userlog.NewAddress = userdetail.Address;
                       userlog.NewPinCode = userdetail.PinCode;
                       userlog.NewMobileNo = userdetail.MobileNo;
                       userlog.EmailId = userdetail.EmailId;
                       db.UserDetailLogs.Add(userlog);
                       db.SaveChanges();
                       if (createStatus == MembershipCreateStatus.Success)
                       {
                           FormsAuthentication.SetAuthCookie(model.UserName, false /* createPersistentCookie */);
                           return RedirectToAction("SendMailReg");
                       }
                    // If we got this far, something failed, redisplay form
                    return View(model);
                    }
                  
                 else
                 {
                   ModelState.AddModelError("", "");
                    return View(model);
                 }
                }
                else
                {
                ModelState.AddModelError("", "Please Fill Requried Field.");
                    return View(model);
                }
                }
              
                 else
                {
                ViewBag.ErrMessage = "Captcha is not valid.";
                return View(model);
                }
            return View();
        }

        public ActionResult SendMailReg()
        {
            //SmtpSection secobj = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");
            using (MailMessage mm = new MailMessage())
            {
                var email = Session["regemail"];
                string From = "bconnect2018@gmail.com";
                mm.From = new MailAddress(From,"Book Connect");
                mm.To.Add(email.ToString());
                mm.Subject = "Registration Mail";
                mm.Body = ("Dear user "+email+", ThankYou for Register.");
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; ;
                smtp.EnableSsl = true;
                string UserName = "bconnect2018@gmail.com";
                string Password = "password2018";
                NetworkCredential network = new NetworkCredential(UserName, Password);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = network;
                smtp.Port = 587;
                smtp.Send(mm);
            }
            return RedirectToAction("Index","Home");
        }

        //
        // GET: /Account/ChangePassword

        [Authorize]
        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Account/ChangePassword

        [Authorize]
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {

                // ChangePassword will throw an exception rather
                // than return false in certain failure scenarios.
                bool changePasswordSucceeded;
                try
                {
                    MembershipUser currentUser = Membership.GetUser(User.Identity.Name, true /* userIsOnline */);
                    changePasswordSucceeded = currentUser.ChangePassword(model.OldPassword, model.NewPassword);
                }
                catch (Exception)
                {
                    changePasswordSucceeded = false;
                }

                if (changePasswordSucceeded)
                {
                    return RedirectToAction("ChangePasswordSuccess");
                }
                else
                {
                    ModelState.AddModelError("", "The current password is incorrect or the new password is invalid.");
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ChangePasswordSuccess

        public ActionResult ChangePasswordSuccess()
        {
            return View();
        }

        //
        // POST: /Account/LogOff

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();  
    return RedirectToAction("Index", "Home");  
        }  
       
        public ActionResult Manage()
        {
            return View();
        }
    
        public ActionResult UserConfirm()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserConfirm(ConfirmUser sp, string returnUrl)
        {
            var email = sp.EmailId;
                Session["EmailID"] = email;
                if (ModelState.IsValid)
                {

                    #region
                    using (UserDBEntities entities = new UserDBEntities())
                    {
                        aspnet_Membership users = (from user in entities.aspnet_Membership
                                                   where user.Email == email
                                                   select user).FirstOrDefault();

                        if (users == null)
                        {
                            ModelState.AddModelError("", " ");
                            return View();
                        }
                        return RedirectToAction("SendMail");
                    }


                    #endregion
                }
               return View();
            
        }
            
        

        public ActionResult SendMail()
        {
            //SmtpSection secobj = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");
            using (MailMessage mm = new MailMessage())
            {
                var email = Session["EmailID"];
                
                var callbackUrl = Url.Action("Forget","Account",new{UserId = email}, protocol: Request.Url.Scheme);
                //localhost48190/Account/Forget.cshtml
                string From = "bconnect2018@gmail.com";
                mm.From = new MailAddress(From,"Book Connect");
                mm.To.Add(email.ToString());
                mm.Subject = "Reset Password";
                mm.Body =  ("Dear User"+email+"Please clicking this link to change your password: <a href=\""
                                               + callbackUrl + "\">link</a>");




                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                string UserName = "bconnect2018@gmail.com";
                string Password = "password2018";
                NetworkCredential network = new NetworkCredential(UserName, Password);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = network;
                smtp.Port = 587;
                smtp.Send(mm);
            }
            return RedirectToAction("MailSend");
        }

        public ActionResult MailSend()
        {
            return View();
        }
    
        public ActionResult Forget()
        {
            return View();
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Forget(ForgetPassword fp)
        {
            var email = Session["EmailID"];
            bool ChangePassword ;
            try
                {
                    
                    
                    var pass = (from p in db.aspnet_Membership
                                join q in db.aspnet_Users on p.UserId equals q.UserId
                                where p.Email == email
                                    select q.UserName).FirstOrDefault();
                   string username = "Username";
                    //string password = "newpassword";
                    MembershipUser mu = Membership.GetUser(pass);
                    mu.ChangePassword(mu.ResetPassword(),fp.NewPassword);
                    ChangePassword = true;
                    //changePasswordSucceeded = Email.ChangePassword(pass,fp.NewPassword);
                }
            catch (Exception)
            {
                ChangePassword = false;
            }

            if (ChangePassword)
            {
                return RedirectToAction("ChangePasswordSuccess");
            }
            else
            {
                ModelState.AddModelError("", "The current password is incorrect or the new password is invalid.");
                return View(); 
            }
            return RedirectToAction("LogOn"); 
        }
    }
}