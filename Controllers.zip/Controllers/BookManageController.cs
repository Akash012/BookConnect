﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.IO;
using System.Data.SqlClient;
using System.Web.Security;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using PagedList;

namespace BC.Controllers
{
    public class BookManageController : Controller
    {
        //
        // GET: /BookManage/

        private UserDBEntities db = new UserDBEntities();

        //
        // GET: /Default1/

        public ActionResult Index(int? page)
        {
            List<BookModel> bookmodel = new List<BookModel>();
            //Category category = new Category().T;
            List<BookTable> booktable = db.BookTables.Where(x => x.StatusId == 1 || x.StatusId == 3).ToList();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            foreach (var d in booktable)
            {
                BookModel pm = new BookModel();
                pm.ID = d.ID;
                pm.Name = d.Name;
                pm.AuthorName = d.AuthorName;
                pm.ImageUrl = d.ImageUrl;
                pm.CategoryName = db.Categories.Where(x => x.CategoryId == d.CategoryId).Select(x => x.CategoryName).FirstOrDefault();
                pm.BookDescription = d.BookDescription;
                pm.BookStatus = d.BookStatus;
                pm.Quantity = d.Quantity;
                pm.AvailableQuantity = d.AvailableQuantity;
                pm.IssueQuantity = d.IssueQuantity;
                pm.BookCost = d.BookCost;
                bookmodel.Add(pm);
            }
            return View(bookmodel.ToPagedList(pageNumber, pageSize));
        }

        //
        // GET: /Default1/Details/5

        public ActionResult Details(BookModel model ,int id = 0)
        {
            //BookTable booktable = db.BookTables.Find(id);
            var booktable = (from a in db.BookTables
                             where a.ID == id
                             select a).FirstOrDefault();
            if (booktable == null)
            {
                return HttpNotFound();
            }
            else
            {
            model.AuthorName = booktable.AuthorName;
            model.AvailableQuantity = booktable.AvailableQuantity;
            model.BookCost = booktable.BookCost;
            model.BookDescription = booktable.BookDescription;
            model.BookStatus = booktable.BookStatus;
            model.CategoryName = db.Categories.Where(x => (x.CategoryId == booktable.CategoryId)).Select(x => x.CategoryName).FirstOrDefault();
            model.ID = booktable.ID;
            model.ImageUrl = booktable.ImageUrl;
            model.IssuedQuantity = booktable.IssueQuantity;
            model.Name = booktable.Name;
            model.Quantity = booktable.Quantity;
            
            }
            return View(model);
        }

        //
        // GET: /Default1/Create

        public ActionResult Create()
        {
            BookModel book = new BookModel();
            List<SelectListItem> category = new List<SelectListItem>();

            var list = (from data in db.Categories select data).ToList();

            foreach (var d in list)
            {
                SelectListItem pm = new SelectListItem();
                pm.Value = d.CategoryId.ToString();
                pm.Text = d.CategoryName;
                category.Add(pm);
            }
            book.Category = category;
            return View(book);
        }

        //
        // POST: /Default1/Create

        
        [HttpPost]
        public ActionResult Create(FormCollection fc, HttpPostedFileBase file, BookModel book)
        {
            BookTable booktable = new BookTable();
            var allowedExtensions = new[] { ".Jpg", ".png", ".jpg", ".jpeg" };

            var fileName = Path.GetFileName(file.FileName); //getting only file name(ex-ganesh.jpg)
            var ext = Path.GetExtension(file.FileName); //getting the extension (ex- .jpg)
            if (allowedExtensions.Contains(ext)) //check what type of extension
            {
                string name = Path.GetFileNameWithoutExtension(fileName);
                int id = 0;
                try
                {
                    id = (from s in db.BookTables select s.ID).Max();
                }
                catch (Exception ex) { }
                //booktable.Id = Convert.ToInt32(fc["Id"]);
                string myfile = "IMG-" + (id + 1) + ext; //appending the name with Id
                //store the file inside ~/project filder(Img)
                var path = Path.Combine(Server.MapPath("~/Img"), myfile);



                booktable.Name = fc["Name"].ToString();
                booktable.AuthorName = fc["AuthorName"].ToString();
                booktable.ImageUrl = "/Img/" + myfile; //getting complete url
                booktable.CategoryId = Convert.ToInt32(fc["CategoryId"]);
                booktable.BookDescription = fc["BookDescription"].ToString();
                booktable.Quantity = Convert.ToInt32(fc["Quantity"]);
                booktable.AvailableQuantity = Convert.ToInt32(fc["Quantity"]);
                booktable.IssueQuantity = 0;
                booktable.BookCost = Convert.ToInt32(fc["BookCost"]);
                booktable.StatusId = 1;
                if (booktable.AvailableQuantity == 0)
                {
                    booktable.BookStatus = "Not Available";
                }
                else
                {
                    booktable.BookStatus = "Available";
                }

                if (ModelState.IsValid)
                {
                    BooksLog bookslog = new BooksLog();
                    db.BookTables.Add(booktable);
                    db.SaveChanges();
                    file.SaveAs(path);
                    bookslog.ID = booktable.ID;
                    bookslog.ActionType = "Added";
                    bookslog.ActionDate = System.DateTime.Now;
                    bookslog.NewName = booktable.Name;
                    bookslog.NewAuthorName = booktable.AuthorName;
                    bookslog.NewCategoryId = booktable.CategoryId;
                    bookslog.NewBookDescription = booktable.BookDescription;
                    bookslog.NewQuantity = booktable.Quantity;
                    bookslog.NewAvailableQuantity = booktable.AvailableQuantity;
                    bookslog.NewIssueQuantity = booktable.IssueQuantity;
                    bookslog.NewBookCost = booktable.BookCost;
                    db.BooksLogs.Add(bookslog);
                    //db.Entry(bookslog).State = EntityState.Added;

                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                List<SelectListItem> category = new List<SelectListItem>();

                var list = (from data in db.Categories select data).ToList();

                foreach (var d in list)
                {
                    SelectListItem pm = new SelectListItem();
                    pm.Value = d.CategoryId.ToString();
                    pm.Text = d.CategoryName;
                    if (pm.Value == booktable.CategoryId.ToString())
                    {
                        pm.Selected = true;
                    }
                    category.Add(pm);
                }
                book.Category = category;
            }
            else
            {
                ViewBag.message = "Please choose only Image file";
            }





            return View();

        }



        //
        // GET: /Default1/Edit/5

        public ActionResult Edit(int id = 0)
        {
            BookModel bookmodel = new BookModel();
            BookTable booktable = db.BookTables.Find(id);
            //BookTable olddata = (from s in db.BookTables where s.ID == bookmodel.ID select s).FirstOrDefault();
            HttpContext.Session.Add("OldData", booktable);
            if (booktable == null)
            {
                return HttpNotFound();
            }
            else
            {
                List<SelectListItem> category = new List<SelectListItem>();

                var list = (from data in db.Categories select data).ToList();

                foreach (var d in list)
                {
                    SelectListItem pm = new SelectListItem();
                    pm.Value = d.CategoryId.ToString();
                    pm.Text = d.CategoryName;
                    if (pm.Value == booktable.CategoryId.ToString())
                    {
                        pm.Selected = true;
                    }
                    category.Add(pm);
                }
                bookmodel.Category = category;
                bookmodel.ID = booktable.ID;
                bookmodel.Name = booktable.Name;
                bookmodel.AuthorName = booktable.AuthorName;
                bookmodel.ImageUrl = booktable.ImageUrl;
                bookmodel.CategoryId = booktable.CategoryId;
                bookmodel.BookDescription = booktable.BookDescription;
                bookmodel.BookStatus = booktable.BookStatus;
                bookmodel.Quantity = booktable.Quantity;
                bookmodel.AvailableQuantity = booktable.AvailableQuantity;
                bookmodel.IssueQuantity = booktable.IssueQuantity;
                bookmodel.BookCost = booktable.BookCost;


            }
            return View(bookmodel);
        }

        //
        // POST: /Default1/Edit/5

        [HttpPost]
        public ActionResult Edit(FormCollection fc, HttpPostedFileBase file, BookModel bookmodel)
        {
            BooksLog bookslog = new BooksLog();
            BookTable booktable = new BookTable();
            BookTable olddata = Session["OldData"] as BookTable;

            //string imgname = (from s in db.BookTables
            //                 where s.Id == bookmodel.Id
            //               select s.FileName).FirstOrDefault();
            //if (System.IO.File.Exists(Server.MapPath(@"~\Image\Img\" + imgname)))
            //{
            //    System.IO.File.Delete(Server.MapPath(@"~\Image\Img\" + imgname));
            //}
            try
            {
                if (!string.IsNullOrEmpty(file.FileName) && !string.IsNullOrWhiteSpace(file.FileName) && file.FileName != "")
                {
                    var allowedExtensions = new[] { ".Jpg", ".png", ".jpg", ".jpeg" };

                    var fileName = Path.GetFileName(file.FileName); //getting only file name(ex-ganesh.jpg)
                    var ext = Path.GetExtension(file.FileName); //getting the extension (ex- .jpg)
                    if (allowedExtensions.Contains(ext)) //check what type of extension
                    {
                        string name = Path.GetFileNameWithoutExtension(fileName);
                        booktable.ID = Convert.ToInt32(fc["Id"]);
                        string myfile = "IMG-" + booktable.ID + ext;
                        var path = Path.Combine(Server.MapPath("~/Img"), myfile);
                        booktable.ImageUrl = "/Img/" + myfile;
                        file.SaveAs(path);
                    }
                }
            }
            catch (Exception)
            {
                booktable.ImageUrl = olddata.ImageUrl;
            }
            booktable.ID = Convert.ToInt32(fc["Id"]);
            booktable.Name = fc["Name"].ToString();
            booktable.AuthorName = fc["AuthorName"].ToString();
            booktable.CategoryId = Convert.ToInt32(fc["CategoryId"]);
            booktable.BookDescription = fc["BookDescription"].ToString();
            booktable.Quantity = Convert.ToInt32(fc["Quantity"]);
            booktable.AvailableQuantity = Convert.ToInt32(fc["AvailableQuantity"]);
            booktable.IssueQuantity = Convert.ToInt32(fc["IssueQuantity"]);
            booktable.BookCost = Convert.ToInt32(fc["BookCost"]);
            booktable.StatusId = 3;
            if (Convert.ToInt32(fc["AvailableQuantity"]) == 0)
            {
                booktable.BookStatus = "Not Available";
            }
            else
            {
                booktable.BookStatus = "Available";
            }
            if (ModelState.IsValid)
            {

                db.Entry(booktable).State = EntityState.Modified;
                //db.Configuration.ValidateOnSaveEnabled = false;
                db.SaveChanges();
                bool IsEdited = false;
                bookslog.ID = booktable.ID;
                bookslog.ActionType = "Edited";
                bookslog.ActionDate = System.DateTime.Now;
                if (booktable.Name == olddata.Name)
                {
                    bookslog.NewName = "NAN";
                    bookslog.OldName = olddata.Name;
                }
                else
                {
                    bookslog.NewName = booktable.Name;
                    bookslog.OldName = olddata.Name;
                    IsEdited = true;
                }
                if (booktable.AuthorName == olddata.AuthorName)
                {
                    bookslog.NewAuthorName = "NAN";
                    bookslog.OldAuthorName = olddata.AuthorName;
                }
                else
                {
                    bookslog.NewAuthorName = booktable.AuthorName;
                    bookslog.OldAuthorName = olddata.AuthorName;
                    IsEdited = true;
                }
                if (booktable.CategoryId == olddata.CategoryId)
                {
                    bookslog.OldCategoryId = olddata.CategoryId;
                }
                else
                {
                    bookslog.NewCategoryId = booktable.CategoryId;
                    bookslog.OldCategoryId = olddata.CategoryId;
                    IsEdited = true;
                }
                if (booktable.BookDescription == olddata.BookDescription)
                {
                    bookslog.NewBookDescription = "NAN";
                    bookslog.OldBookDescription = olddata.BookDescription;
                }
                else
                {
                    bookslog.NewBookDescription = booktable.BookDescription;
                    bookslog.OldBookDescription = olddata.BookDescription;
                    IsEdited = true;
                }
                if (booktable.Quantity == olddata.Quantity)
                {
                    bookslog.OldQuantity = olddata.Quantity;
                }
                else
                {
                    bookslog.NewQuantity = booktable.Quantity;
                    bookslog.OldQuantity = olddata.Quantity;
                    IsEdited = true;
                }
                //bookslog.NewQuantity = booktable.Quantity;
                //bookslog.OldQuantity = olddata.Quantity;
                if (booktable.AvailableQuantity == olddata.AvailableQuantity)
                {
                    bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
                }
                else
                {
                    bookslog.NewAvailableQuantity = booktable.AvailableQuantity;
                    bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
                    IsEdited = true;
                }
                //bookslog.NewAvailableQuantity = booktable.AvailableQuantity;
                //bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
                if (booktable.IssueQuantity == olddata.IssueQuantity)
                {
                    bookslog.OldIssueQuantity = olddata.IssueQuantity;
                }
                else
                {
                    bookslog.NewIssueQuantity = booktable.IssueQuantity;
                    bookslog.OldIssueQuantity = olddata.IssueQuantity;
                    IsEdited = true;
                }
                //bookslog.NewIssueQuantity = booktable.IssueQuantity;
                //bookslog.OldIssueQuantity = olddata.IssueQuantity;
                if (booktable.BookCost == olddata.BookCost)
                {
                    bookslog.OldBookCost = olddata.BookCost;
                }
                else
                {
                    bookslog.NewBookCost = booktable.BookCost;
                    bookslog.OldBookCost = olddata.BookCost;
                    IsEdited = true;
                }
                //bookslog.NewBookCost = booktable.BookCost;
                //bookslog.OldBookCost = olddata.BookCost;
                //System.Web.UI.ScriptManager script_manager = new System.Web.UI.ScriptManager();
                if (IsEdited == true)
                {
                    db.BooksLogs.Add(bookslog);
                    db.Entry(bookslog).State = EntityState.Added;
                    db.SaveChanges();
                    //ViewData["Message"] = "bijbkbwk";
                    HttpContext.Session.Add("Message", "Data save sucessfully");

                }
                else
                {
                    //ViewData["Message"] = "aaaaaaaaa";
                    HttpContext.Session.Add("Message", "Changes not saved");
                }
                HttpContext.Session.Remove("OldData");
                return RedirectToAction("Index");
            }
            List<SelectListItem> category = new List<SelectListItem>();

            var list = (from data in db.Categories select data).ToList();

            foreach (var d in list)
            {
                SelectListItem pm = new SelectListItem();
                pm.Value = d.CategoryId.ToString();
                pm.Text = d.CategoryName;
                if (pm.Value == booktable.CategoryId.ToString())
                {
                    pm.Selected = true;
                }
                category.Add(pm);
            }
            bookmodel.Category = category;
            bookmodel.ImageUrl = olddata.ImageUrl;
            return View(bookmodel);
        }

        //
        // GET: /Default1/Delete/5

        public ActionResult Delete(int id = 0)
        {
            BookTable booktable = db.BookTables.Find(id);
            HttpContext.Session.Add("OldData", booktable);
            if (booktable == null)
            {
                return HttpNotFound();
            }
            return View(booktable);
        }

        //
        // POST: /Default1/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            BooksLog bookslog = new BooksLog();
            BookTable booktable = db.BookTables.Find(id);
            BookTable olddata = Session["OldData"] as BookTable;
            booktable.StatusId = 2;
            //db.BookTables.Remove(booktable);
            bookslog.ID = booktable.ID;
            bookslog.ActionType = "Deleted";
            bookslog.ActionDate = System.DateTime.Now;
            bookslog.OldName = olddata.Name;
            bookslog.OldAuthorName = olddata.AuthorName;
            bookslog.OldCategoryId = olddata.CategoryId;
            bookslog.OldBookDescription = olddata.BookDescription;
            bookslog.OldQuantity = olddata.Quantity;
            bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
            bookslog.OldIssueQuantity = olddata.IssueQuantity;
            bookslog.OldBookCost = olddata.BookCost;
            //db.SaveChanges();

            db.BooksLogs.Add(bookslog);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult DeductionCart()
        {
            BooksLog booklog = new BooksLog();

            var trans = (from s in db.CartTables
                         join b in db.BookTables on s.ID equals b.ID
                         where s.UserName == User.Identity.Name
                          && b.AvailableQuantity > 0
                         select s).ToList();
            BookTable book = new BookTable();
            foreach (var b in trans)
            {
                CartTable cart = (from q in db.CartTables
                                  where b.CartId == q.CartId
                                  select q).FirstOrDefault();
                book = (from a in db.BookTables
                        where (cart.ID == a.ID)
                        select a).FirstOrDefault();
                int AQ = book.AvailableQuantity;
                int AA = book.IssueQuantity;
                HttpContext.Session.Add("olddata", book);
                BookTable books = Session["olddata"] as BookTable;
                book.IssueQuantity = (AA + cart.NoOfQuantity);
                book.AvailableQuantity = (AQ - cart.NoOfQuantity);
                if (ModelState.IsValid)
                {
                    db.Entry(book).State = EntityState.Modified;
                    db.SaveChanges();
                }
                booklog.ID = book.ID;
                booklog.ActionType = "Edited";
                booklog.ActionDate = System.DateTime.Now;
                booklog.NewName = "NAN";
                booklog.OldName = books.Name;
                booklog.NewAuthorName = "NAN";
                booklog.OldAuthorName = books.AuthorName;
                booklog.OldCategoryId = books.CategoryId;
                booklog.NewBookDescription = "NAN";
                booklog.OldBookDescription = books.BookDescription;
                booklog.OldQuantity = books.Quantity;
                booklog.OldAvailableQuantity = books.AvailableQuantity;
                booklog.NewAvailableQuantity = book.AvailableQuantity;
                booklog.OldIssueQuantity = books.IssueQuantity;
                booklog.NewIssueQuantity = book.IssueQuantity;
                booklog.OldBookCost = books.BookCost;
                db.BooksLogs.Add(booklog);
                if (ModelState.IsValid)
                {
                    db.Entry(booklog).State = EntityState.Added;
                    db.SaveChanges();
                }
            }

            return RedirectToAction("CartDelete", "Home");
        }

        public ActionResult DeductionOrder()
        {
            BooksLog booklog = new BooksLog();
            TransactionTable trans = Session["dedu"] as TransactionTable;
            BookTable book = new BookTable();
            book = (from a in db.BookTables
                    where trans.BookId == a.ID
                    select a).FirstOrDefault();
            int AQ = book.AvailableQuantity;
            int AA = book.IssueQuantity;
            HttpContext.Session.Add("olddata", book);
            BookTable books = Session["olddata"] as BookTable;
            book.IssueQuantity = (AA + trans.NoOfQuantity);
            book.AvailableQuantity = (AQ - trans.NoOfQuantity);
            if (ModelState.IsValid)
            {
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
            }
            booklog.ID = book.ID;
            booklog.ActionType = "Edited";
            booklog.ActionDate = System.DateTime.Now;
            booklog.NewName = "NAN";
            booklog.OldName = books.Name;
            booklog.NewAuthorName = "NAN";
            booklog.OldAuthorName = books.AuthorName;
            booklog.OldCategoryId = books.CategoryId;
            booklog.NewBookDescription = "NAN";
            booklog.OldBookDescription = books.BookDescription;
            booklog.OldQuantity = books.Quantity;
            booklog.OldAvailableQuantity = books.AvailableQuantity;
            booklog.NewAvailableQuantity = book.AvailableQuantity;
            booklog.OldIssueQuantity = books.IssueQuantity;
            booklog.NewIssueQuantity = book.IssueQuantity;
            booklog.OldBookCost = books.BookCost;
            db.BooksLogs.Add(booklog);
            if (ModelState.IsValid)
            {
                db.Entry(booklog).State = EntityState.Added;
                db.SaveChanges();
            }
            HttpContext.Session.Remove("dedu");
            return RedirectToAction("OrderDelete", "Home");
        }

        public ActionResult Search()
        {
            var book = db.BookTables.Where(x => (x.StatusId == 1) || (x.StatusId == 3)).ToList();
            return View(book);
        }

        [HttpPost]
        public ActionResult Search(int? page)
        {
            List<BookModel> model = new List<BookModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            string filter = Request["search"];
            if (!string.IsNullOrEmpty(filter) && !string.IsNullOrWhiteSpace(filter))
            {
                var books = (from a in db.BookTables
                             join b in db.Categories on a.CategoryId equals b.CategoryId
                             where (((a.Name.Contains(filter)) || (a.AuthorName.Contains(filter))
                              || (b.CategoryName.Contains(filter)) || (a.BookStatus.Contains(filter)))
                                 && ((a.StatusId == 1) || (a.StatusId == 3)))
                             select a).ToList();
                foreach (var d in books)
                {
                    BookModel pm = new BookModel();
                    pm.ID = d.ID;
                    pm.Name = d.Name;
                    pm.AuthorName = d.AuthorName;
                    pm.ImageUrl = d.ImageUrl;
                    pm.CategoryName = db.Categories.Where(x => x.CategoryId == d.CategoryId).Select(x => x.CategoryName).FirstOrDefault();
                    pm.BookDescription = d.BookDescription;
                    pm.BookStatus = d.BookStatus;
                    pm.Quantity = d.Quantity;
                    pm.AvailableQuantity = d.AvailableQuantity;
                    pm.IssueQuantity = d.IssueQuantity;
                    pm.BookCost = d.BookCost;
                    model.Add(pm);
                }
                
            }
            return View(model.ToPagedList(pageNumber, pageSize));
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        
    }
}
