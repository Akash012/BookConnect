﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.IO;
using System.Data.SqlClient;
using System.Web.Security;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using PagedList;


namespace BC.Controllers
{
    
    public class AdminController : Controller
    {
        UserDBEntities db = new UserDBEntities();


        public ActionResult Index()
        {
            if (Request.IsAuthenticated)
            {
                AdminCountModel model = new AdminCountModel();
                var porder = (from a in db.TransactionTables
                              where a.StatusId == 1
                              select a).Count();
                model.POrder = porder;

                var dorder = (from a in db.TransactionTables
                              where a.StatusId == 2
                              select a).Count();
                model.DOrder = dorder;

                var reg = (from a in db.UserDetails
                           select a).Count();
                model.Reg = reg;

                var popu = (from a in db.PopularTables
                            select a.Number).FirstOrDefault();
                var popular = (from a in db.BookTables
                               where a.IssueQuantity >= popu
                               select a).Count();
                model.Popular = popular;
                return View(model);
            }

            else
            {
                return RedirectToAction("LogOn", "Account");
            }

        }
    
        public ActionResult Manage()
        {
            return View();
        }

        //public ActionResult Contact()
        //{
        //    List<ContactU> contact = new List<ContactU>();
        //    contact = (from a in db.ContactUs select a).ToList();
        //    foreach (var b in contact)
        //    {
        //        ContactU c = new ContactU();
        //        c.Name = b.Name;
        //        c.EmailId = b.EmailId;
        //        c.Subject = b.Subject;
        //        c.Message = b.Message;
        //        contact.Add(c);
        //    }
        //    return View(contact);
        //}
    }
}