﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using PagedList;

namespace BC.Controllers
{
    public class AdminCategoryController : Controller
    {
        private UserDBEntities db = new UserDBEntities();

        //
        // GET: /AdminCategory/

        public ActionResult Index()
        {
            return View(db.Categories.ToList());
        }

        //
        // GET: /AdminCategory/Details/5

        //public ActionResult Details(int id = 0)
        //{
        //    Category category = db.Categories.Find(id);
        //    if (category == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(category);
        //}

        //
        // GET: /AdminCategory/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /AdminCategory/Create

        [HttpPost]
        public ActionResult Create(Category category)
        {
            if (ModelState.IsValid)
            {
                db.Categories.Add(category);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(category);
        }

        //
        // GET: /AdminCategory/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Category category = db.Categories.Find(id);
            if (category == null)
            {
                return HttpNotFound();
            }
            return View(category);
        }

        //
        // POST: /AdminCategory/Edit/5

        [HttpPost]
        public ActionResult Edit(Category category)
        {
            if (ModelState.IsValid)
            {
                db.Entry(category).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(category);
        }

        //
        // GET: /AdminCategory/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Category category = db.Categories.Find(id);
            if (category == null)
            {
                return HttpNotFound();
            }
            return View(category);
        }

        //
        // POST: /AdminCategory/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Category category = db.Categories.Find(id);
            db.Categories.Remove(category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Search()
        {
            var cat = db.Categories.ToList();
            return View(cat);
        }
        [HttpPost]
        public ActionResult Search(int? page)
        {
            List<CategoryModel> model = new List<CategoryModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            string filter = Request["search"];
            if (!string.IsNullOrEmpty(filter) && !string.IsNullOrWhiteSpace(filter))
            {
                var list = (from a in db.Categories
                            where (a.CategoryName.Contains(filter))
                            select a).ToList();
                foreach (var d in list)
                {
                    CategoryModel cm = new CategoryModel();
                    cm.CategoryId = d.CategoryId;
                    cm.CategoryName = d.CategoryName;
                    model.Add(cm);
                }
            }
            return View(model.ToPagedList(pageNumber, pageSize));
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}