﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;

namespace BC.Controllers
{
    public class AdminPopularController : Controller
    {
        private UserDBEntities db = new UserDBEntities();

        //
        // GET: /Default1/

        public ActionResult Index()
        {
            return View(db.PopularTables.ToList());
        }

        ////
        //// GET: /Default1/Details/5

        //public ActionResult Details(int id = 0)
        //{
        //    PopularTable populartable = db.PopularTables.Find(id);
        //    if (populartable == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(populartable);
        //}

        ////
        //// GET: /Default1/Create

        //public ActionResult Create()
        //{
        //    return View();
        //}

        ////
        //// POST: /Default1/Create

        //[HttpPost]
        //public ActionResult Create(PopularTable populartable)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.PopularTables.Add(populartable);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(populartable);
        //}

        //
        // GET: /Default1/Edit/5

        public ActionResult Edit(int id = 0)
        {
            PopularTable populartable = db.PopularTables.Find(id);
            if (populartable == null)
            {
                return HttpNotFound();
            }
            return View(populartable);
        }

        //
        // POST: /Default1/Edit/5

        [HttpPost]
        public ActionResult Edit(PopularTable populartable, FormCollection fc)
        {
            if (!string.IsNullOrEmpty(fc["Number"]) && !string.IsNullOrWhiteSpace(fc["Number"]))
            {
                populartable.PopularId = 1;
                populartable.Number = Convert.ToInt32(fc["Number"]);
            
                if (ModelState.IsValid)
                {
                    db.Entry(populartable).State = EntityState.Modified;
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("","");
                return View();
            }
            
        }

        ////
        //// GET: /Default1/Delete/5

        //public ActionResult Delete(int id = 0)
        //{
        //    PopularTable populartable = db.PopularTables.Find(id);
        //    if (populartable == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(populartable);
        //}

        ////
        //// POST: /Default1/Delete/5

        //[HttpPost, ActionName("Delete")]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    PopularTable populartable = db.PopularTables.Find(id);
        //    db.PopularTables.Remove(populartable);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}