﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using PagedList;
using System.Data.Entity;

namespace BC.Controllers
{
    public class BooksController : Controller
    {
        private UserDBEntities db = new UserDBEntities();
        //
        // GET: /Books/

        public ActionResult Index()
        {
            return View();
        }
        //GET
        public ActionResult Action_Adventure(int? page,string author)
        {
            int max = Convert.ToInt32(Request["Max"]);
            int min = Convert.ToInt32(Request["Mini"]);
            
            List<BookModel> bookmodel = new List<BookModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 16;
            int pageNumber = (page ?? 1);
            if (max == 0)
            {
                if (string.IsNullOrEmpty(author) && string.IsNullOrWhiteSpace(author))
                {
                    List<BookTable> booktable = db.BookTables.Where(x => ((x.CategoryId == 1) && (x.StatusId == 1 || x.StatusId == 3))).ToList();
                    foreach (var d in booktable)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
                else
                {

                    List<BookTable> bookt = db.BookTables.Where(x => (x.AuthorName == author) && (x.CategoryId == 1) && (x.StatusId == 1 || x.StatusId == 3)).ToList();
                    foreach (var d in bookt)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
            }
            else
            {
                List<BookTable> book = db.BookTables.Where(x => (x.BookCost <= max) && (x.BookCost >= min) && (x.StatusId == 1 || x.StatusId == 3) && (x.CategoryId == 1)).OrderByDescending(x => x.BookCost).ToList();
                foreach (var e in book)
                {
                    BookModel pp = new BookModel();
                    pp.ID = e.ID;
                    pp.Name = e.Name;
                    pp.AuthorName = e.AuthorName;
                    pp.ImageUrl = e.ImageUrl;
                    pp.BookCost = e.BookCost;
                    bookmodel.Add(pp);
                }
                return View(bookmodel.ToPagedList(pageNumber, pageSize));
            }
        }
       
        public ActionResult Romance(int? page, string author)
        {
            int max = Convert.ToInt32(Request["Max"]);
            int min = Convert.ToInt32(Request["Min"]);
            List<BookModel> bookmodel = new List<BookModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 16;
            int pageNumber = (page ?? 1);
            if (max == 0)
            {
                if (string.IsNullOrEmpty(author) && string.IsNullOrWhiteSpace(author))
                {
                    List<BookTable> booktable = db.BookTables.Where(x => ((x.CategoryId == 2) && (x.StatusId == 1 || x.StatusId == 3))).ToList();
                    foreach (var d in booktable)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
                else
                {

                    List<BookTable> bookt = db.BookTables.Where(x => (x.AuthorName == author) && (x.CategoryId == 2) && (x.StatusId == 1 || x.StatusId == 3)).ToList();
                    foreach (var d in bookt)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
            }
            else
            {
                List<BookTable> book = db.BookTables.Where(x => (x.BookCost <= max) && (x.BookCost >= min) && (x.StatusId == 1 || x.StatusId == 3) && (x.CategoryId == 2)).OrderByDescending(x => x.BookCost).ToList();
                foreach (var e in book)
                {
                    BookModel pp = new BookModel();
                    pp.ID = e.ID;
                    pp.Name = e.Name;
                    pp.AuthorName = e.AuthorName;
                    pp.ImageUrl = e.ImageUrl;
                    pp.BookCost = e.BookCost;
                    bookmodel.Add(pp);
                }
                return View(bookmodel.ToPagedList(pageNumber, pageSize));  
            }
            
        }

        public ActionResult Biographies(int? page, string author)
        {
            int max = Convert.ToInt32(Request["Max"]);
            int min = Convert.ToInt32(Request["Min"]);
            List<BookModel> bookmodel = new List<BookModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 16;
            int pageNumber = (page ?? 1);
            if (max == 0)
            {
                if (string.IsNullOrEmpty(author) && string.IsNullOrWhiteSpace(author))
                {
                    List<BookTable> booktable = db.BookTables.Where(x => ((x.CategoryId == 4) && (x.StatusId == 1 || x.StatusId == 3))).ToList();
                    foreach (var d in booktable)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
                else
                {

                    List<BookTable> bookt = db.BookTables.Where(x => (x.AuthorName == author) && (x.CategoryId == 4) && (x.StatusId == 1 || x.StatusId == 3)).ToList();
                    foreach (var d in bookt)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
            }
            else
            {
                List<BookTable> book = db.BookTables.Where(x => (x.BookCost <= max) && (x.BookCost >= min) && (x.StatusId == 1 || x.StatusId == 3) && (x.CategoryId == 4)).OrderByDescending(x => x.BookCost).ToList();
                foreach (var e in book)
                {
                    BookModel pp = new BookModel();
                    pp.ID = e.ID;
                    pp.Name = e.Name;
                    pp.AuthorName = e.AuthorName;
                    pp.ImageUrl = e.ImageUrl;
                    pp.BookCost = e.BookCost;
                    bookmodel.Add(pp);
                }
                return View(bookmodel.ToPagedList(pageNumber, pageSize));
            }
        }

        public ActionResult Historical_Fiction(int? page, string author)
        {
            int max = Convert.ToInt32(Request["Max"]);
            int min = Convert.ToInt32(Request["Min"]);
            List<BookModel> bookmodel = new List<BookModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 16;
            int pageNumber = (page ?? 1);
            if (max == 0)
            {
                if (string.IsNullOrEmpty(author) && string.IsNullOrWhiteSpace(author))
                {
                    List<BookTable> booktable = db.BookTables.Where(x => ((x.CategoryId == 5) && (x.StatusId == 1 || x.StatusId == 3))).ToList();
                    foreach (var d in booktable)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
                else
                {

                    List<BookTable> bookt = db.BookTables.Where(x => (x.AuthorName == author) && (x.CategoryId == 5) && (x.StatusId == 1 || x.StatusId == 3)).ToList();
                    foreach (var d in bookt)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
            }
            else
            {
                List<BookTable> book = db.BookTables.Where(x => (x.BookCost <= max) && (x.BookCost >= min) && (x.StatusId == 1 || x.StatusId == 3) && (x.CategoryId == 5)).OrderByDescending(x => x.BookCost).ToList();
                foreach (var e in book)
                {
                    BookModel pp = new BookModel();
                    pp.ID = e.ID;
                    pp.Name = e.Name;
                    pp.AuthorName = e.AuthorName;
                    pp.ImageUrl = e.ImageUrl;
                    pp.BookCost = e.BookCost;
                    bookmodel.Add(pp);
                }
                return View(bookmodel.ToPagedList(pageNumber, pageSize));
            }
        }

        public ActionResult Sci_fi(int? page, string author)
        {
            int max = Convert.ToInt32(Request["Max"]);
            int min = Convert.ToInt32(Request["Min"]);
            List<BookModel> bookmodel = new List<BookModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 16;
            int pageNumber = (page ?? 1);
            if (max == 0)
            {
                if (string.IsNullOrEmpty(author) && string.IsNullOrWhiteSpace(author))
                {
                    List<BookTable> booktable = db.BookTables.Where(x => ((x.CategoryId == 3) && (x.StatusId == 1 || x.StatusId == 3))).ToList();
                    foreach (var d in booktable)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
                else
                {

                    List<BookTable> bookt = db.BookTables.Where(x => (x.AuthorName == author) && (x.CategoryId == 3) && (x.StatusId == 1 || x.StatusId == 3)).ToList();
                    foreach (var d in bookt)
                    {
                        BookModel pm = new BookModel();
                        pm.ID = d.ID;
                        pm.Name = d.Name;
                        pm.AuthorName = d.AuthorName;
                        pm.ImageUrl = d.ImageUrl;
                        pm.BookCost = d.BookCost;
                        bookmodel.Add(pm);
                    }
                    return View(bookmodel.ToPagedList(pageNumber, pageSize));
                }
            }
            else
            {
                List<BookTable> book = db.BookTables.Where(x => (x.BookCost <= max) && (x.BookCost >= min) && (x.StatusId == 1 || x.StatusId == 3) && (x.CategoryId == 3)).OrderByDescending(x => x.BookCost).ToList();
                foreach (var e in book)
                {
                    BookModel pp = new BookModel();
                    pp.ID = e.ID;
                    pp.Name = e.Name;
                    pp.AuthorName = e.AuthorName;
                    pp.ImageUrl = e.ImageUrl;
                    pp.BookCost = e.BookCost;
                    bookmodel.Add(pp);
                }
                return View(bookmodel.ToPagedList(pageNumber, pageSize));
            }
        }
       
        public ActionResult Detail(int id = 0)
        {
            List<SelectListItem> qty = new List<SelectListItem>();
            BookModel bookmodel = new BookModel();
            BookTable booktable = new BookTable();

            if (id != 0)
            {
                Session["id"] = id;
                var list = (from a in db.BookTables
                            where a.ID == id
                            select a).FirstOrDefault();
                bookmodel.ID = list.ID;
                bookmodel.Name = list.Name;
                bookmodel.AvailableQuantity = list.AvailableQuantity;
                bookmodel.AuthorName = list.AuthorName;
                bookmodel.BookCost = list.BookCost;
                bookmodel.BookDescription = list.BookDescription;
                bookmodel.ImageUrl = list.ImageUrl;
            }
            else
            {
                id = Convert.ToInt32(Session["id"]);
                var list = (from a in db.BookTables
                            where a.ID == id
                            select a).FirstOrDefault();
                bookmodel.ID = list.ID;
                bookmodel.Name = list.Name;
                bookmodel.AvailableQuantity = list.AvailableQuantity;
                bookmodel.AuthorName = list.AuthorName;
                bookmodel.BookCost = list.BookCost;
                bookmodel.BookDescription = list.BookDescription;
                bookmodel.ImageUrl = list.ImageUrl;
                
            }
            HttpContext.Session.Add("Bookdetail", bookmodel);
            
            //for (int i = 1; i <= bookmodel.AvailableQuantity; i++)
            //{
            //    SelectListItem pm = new SelectListItem();
            //    pm.Text = i.ToString();
            //    pm.Value = i.ToString();
            //    qty.Add(pm);
                
            //}
            //bookmodel.AvailableQuantityList = qty;
            return View(bookmodel);
        }

       
        public ActionResult Search()
        {
           
            var book = db.BookTables.ToList();
            return View(book);
        }
        //POST
        [HttpPost]
        public ActionResult Search(BookModel book)
        {
         
            //BookTable bk = new BookTable();
            List<BookTable> booktable = new List<BookTable>();
           
            string searchParameter = Request["search"];
            
                if (!string.IsNullOrWhiteSpace(searchParameter) && !string.IsNullOrEmpty(searchParameter))
                {
                    var list = (from a in db.BookTables
                                join b in db.Categories on a.CategoryId equals b.CategoryId
                                where ((a.Name.Contains(searchParameter)
                                || a.AuthorName.Contains(searchParameter)
                                || b.CategoryName.Contains(searchParameter)) && (a.StatusId == 1 || a.StatusId == 3))
                                select new
                                {
                                    ID = a.ID,
                                    Name = a.Name,
                                    AuthorName = a.AuthorName,
                                    ImageUrl = a.ImageUrl,
                                    CategoryName = b.CategoryName,
                                    BookCost = a.BookCost
                                });
                    foreach (var a in list)
                    {
                        BookTable pm = new BookTable();
                        pm.ID = a.ID;
                        pm.Name = a.Name;
                        pm.AuthorName = a.AuthorName;
                        pm.ImageUrl = a.ImageUrl;
                        pm.BookCost = a.BookCost;
                        booktable.Add(pm);
                    }
                }
                book.BookTableList = booktable;
                return View(book);
            
        }

        public ActionResult Cart()
        {
            if (Request.IsAuthenticated)
            {

                CartModel cartmodel = new CartModel();
               CartTable carttable = new CartTable();
               BookTable booktable = new BookTable();
               BookTable bookdetail = Session["Bookdetail"] as BookTable;
               carttable.ID = bookdetail.ID;
               carttable.NoOfQuantity = 1;
               carttable.UserName = User.Identity.Name;
                   db.CartTables.Add(carttable);
                   db.SaveChanges();
                   var cart = (from a in db.CartTables
                               join b in db.BookTables on a.ID equals b.ID
                               where a.UserName == User.Identity.Name
                               group new { a, b } by new { a.ID } into pg
                               let first = pg.FirstOrDefault()
                               let quantity = pg.Sum(s => s.a.NoOfQuantity)
                               select new
                               {
                                   NoOfQuantity = quantity,
                               });
                   Session["count"] = cart.Sum(x => x.NoOfQuantity);
                   HttpContext.Session.Add("Message", "Produt added to cart.");

                   HttpContext.Session.Remove("Bookdetail");

                   return RedirectToAction("Detail");
               }
            
            else
            {
                return RedirectToAction("LogOn", "Account");
            }
}

        public ActionResult Order()
        {
        if (Request.IsAuthenticated)
        {
             OrderTable ordertable = new OrderTable();
                    BookTable booktable = new BookTable();
                    BookTable bookdetail = Session["Bookdetail"] as BookTable;
                       ordertable.ID = bookdetail.ID;
                        ordertable.NoOfQuantity = Convert.ToInt32(Request["Qty"]);
                        ordertable.NoOfQuantity = 1;
                         ordertable.UserName = User.Identity.Name;
                        db.OrderTables.Add(ordertable);
                        db.SaveChanges();
                        HttpContext.Session.Remove("Bookdetail");
                        return RedirectToAction("Index", "User");
                    
        }
        else
        {
                return RedirectToAction("LogOn", "Account");
        }
        }

        
    }
}
