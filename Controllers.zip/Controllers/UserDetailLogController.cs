﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.Web.WebPages;
using System.IO;
using System.Data.SqlClient;
using System.Web.Security;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace BC.Controllers
{
    public class UserDetailLogController : Controller
    {
        public UserDBEntities db = new UserDBEntities();
        //
        // GET: /UserDetailLog/

        public ActionResult Index(UserLog log)
        {
            List<UserDetailLog> userdetail = new List<UserDetailLog>();
            string username = null;
            string actiontype = null;
            string fullname = null;
            string mobileno = null;
            string pincode = null;
            DateTime searchParameter1 = DateTime.Now;
            DateTime searchParameter2 = DateTime.Now;
            if (!string.IsNullOrEmpty(Request["username"]) && !string.IsNullOrWhiteSpace(Request["username"]))
            {
            username = Request["username"];
            }
            if (!string.IsNullOrEmpty(Request["actiontype"]) && !string.IsNullOrWhiteSpace(Request["actiontype"]))
            {
            actiontype = Request["actiontype"];
            }
            if (!string.IsNullOrEmpty(Request["fullname"]) && !string.IsNullOrWhiteSpace(Request["fullname"]))
            {
            fullname = Request["fullname"];
            }
            if (!string.IsNullOrEmpty(Request["mobileno"]) && !string.IsNullOrWhiteSpace(Request["mobileno"]))
            {
            mobileno = Request["mobileno"];
            }
            if (!string.IsNullOrEmpty(Request["pincode"]) && !string.IsNullOrWhiteSpace(Request["pincode"]))
            {
            pincode = Request["pincode"];
            }
            
            if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
            {
                searchParameter1 = Convert.ToDateTime(Request["ActionDate2"]);
                searchParameter2 = Convert.ToDateTime(Request["ActionDate3"]);
            }

            if (!string.IsNullOrWhiteSpace(username) && !string.IsNullOrEmpty(actiontype) && !string.IsNullOrEmpty(fullname)
                && !string.IsNullOrEmpty(mobileno) && !string.IsNullOrEmpty(pincode))
            {
                if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
                {
                    //int m1 = Int32.Parse(mobileno);
                    //int p1 = Int32.Parse(pincode);
                    var list = (from a in db.UserDetailLogs
                                join b in db.UserDetails on a.UserName equals b.UserName
                                where (a.UserName.Contains(username) && a.ActionType.Contains(actiontype) &&
                                ((a.NewFullName.Contains(fullname)) || (a.OldFullName.Contains(fullname))) && ((a.NewMobileNo == (mobileno)) || (a.OldMobileNo == (mobileno)))
                                && ((a.OldPinCode == (pincode)) || (a.NewPinCode == (pincode)))
                                && a.ActionDate >= searchParameter1.Date && a.ActionDate <= searchParameter2.Date)
                                select new
                                {
                                    AuditId = a.AuditId,
                                    ActionType = a.ActionType,
                                    ActionDate = a.ActionDate,
                                    Gender = a.Gender,
                                    Email = a.EmailId,
                                    UserName = a.UserName,
                                    OldFullName = a.OldFullName,
                                    NewFullName = a.NewFullName,
                                    OldAddress = a.OldAddress,
                                    NewAddress = a.NewAddress,
                                    OldMobileNo = a.OldMobileNo,
                                    NewMobileNo = a.NewMobileNo,
                                    OldPinCode = a.OldPinCode,
                                    NewPinCode = a.NewPinCode
                                });
                    foreach (var a in list)
                    {
                        UserDetailLog pm = new UserDetailLog();
                        pm.AuditId = a.AuditId;
                        pm.ActionType = a.ActionType;
                        pm.ActionDate = a.ActionDate;
                        pm.Gender = a.Gender;
                        pm.EmailId = a.Email;
                        pm.UserName = a.UserName;
                        pm.OldFullName = a.OldFullName;
                        pm.NewFullName = a.NewFullName;
                        pm.OldAddress = a.OldAddress;
                        pm.NewAddress = a.NewAddress;
                        pm.OldMobileNo = a.OldMobileNo;
                        pm.NewMobileNo = a.NewMobileNo;
                        pm.OldPinCode = a.OldPinCode;
                        pm.NewPinCode = a.NewPinCode;
                        userdetail.Add(pm);
                    }
                }
                else
                {
                    //int m1 = Int32.Parse(mobileno);
                    //int p1 = Int32.Parse(pincode);
                    var list = (from a in db.UserDetailLogs
                                join b in db.UserDetails on a.UserName equals b.UserName
                                where (a.UserName.Contains(username) && a.ActionType.Contains(actiontype) &&
                                ((a.NewFullName.Contains(fullname)) || (a.OldFullName.Contains(fullname))) && ((a.NewMobileNo == (mobileno)) || (a.OldMobileNo == (mobileno)))
                                && ((a.OldPinCode == (pincode)) || (a.NewPinCode == (pincode))))
                                select new
                                {
                                    AuditId = a.AuditId,
                                    ActionType = a.ActionType,
                                    ActionDate = a.ActionDate,
                                    Gender = a.Gender,
                                    Email = a.EmailId,
                                    UserName = a.UserName,
                                    OldFullName = a.OldFullName,
                                    NewFullName = a.NewFullName,
                                    OldAddress = a.OldAddress,
                                    NewAddress = a.NewAddress,
                                    OldMobileNo = a.OldMobileNo,
                                    NewMobileNo = a.NewMobileNo,
                                    OldPinCode = a.OldPinCode,
                                    NewPinCode = a.NewPinCode
                                });
                    foreach (var a in list)
                    {
                        UserDetailLog pm = new UserDetailLog();
                        pm.AuditId = a.AuditId;
                        pm.ActionType = a.ActionType;
                        pm.ActionDate = a.ActionDate;
                        pm.Gender = a.Gender;
                        pm.EmailId = a.Email;
                        pm.UserName = a.UserName;
                        pm.OldFullName = a.OldFullName;
                        pm.NewFullName = a.NewFullName;
                        pm.OldAddress = a.OldAddress;
                        pm.NewAddress = a.NewAddress;
                        pm.OldMobileNo = a.OldMobileNo;
                        pm.NewMobileNo = a.NewMobileNo;
                        pm.OldPinCode = a.OldPinCode;
                        pm.NewPinCode = a.NewPinCode;
                        userdetail.Add(pm);
                    }
                }
            }
            else if (!string.IsNullOrWhiteSpace(username) || !string.IsNullOrEmpty(actiontype) || !string.IsNullOrEmpty(fullname)
                || !string.IsNullOrEmpty(mobileno) || !string.IsNullOrEmpty(pincode))
                {
                if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
                 {
                    //int m1 = Int32.Parse(mobileno);
                    //int p1 = Int32.Parse(pincode);
                    var list = (from a in db.UserDetailLogs
                                join b in db.UserDetails on a.UserName equals b.UserName
                                 where(a.UserName.Contains(username) || a.ActionType.Contains(actiontype) ||
                                 ((a.NewFullName.Contains(fullname)) || (a.OldFullName.Contains(fullname))) || ((a.NewMobileNo == (mobileno)) || (a.OldMobileNo == (mobileno)))
                                 || ((a.OldPinCode == (pincode)) || (a.NewPinCode == (pincode)))
                                 && a.ActionDate >= searchParameter1.Date && a.ActionDate <= searchParameter2.Date)
                                 select new
                                 {
                                 AuditId = a.AuditId,
                                 ActionType = a.ActionType,
                                 ActionDate = a.ActionDate,
                                 Gender = a.Gender,
                                 Email = a.EmailId,
                                 UserName = a.UserName,
                                 OldFullName = a.OldFullName,
                                 NewFullName = a.NewFullName,
                                 OldAddress = a.OldAddress,
                                 NewAddress = a.NewAddress,
                                 OldMobileNo = a.OldMobileNo,
                                 NewMobileNo = a.NewMobileNo,
                                 OldPinCode = a.OldPinCode,
                                 NewPinCode = a.NewPinCode
                                 });
                    foreach(var a in list)
                    {
                        UserDetailLog pm = new UserDetailLog();
                        pm.AuditId = a.AuditId;
                        pm.ActionType = a.ActionType;
                        pm.ActionDate = a.ActionDate;
                        pm.Gender = a.Gender;
                        pm.EmailId = a.Email;
                        pm.UserName = a.UserName;
                        pm.OldFullName = a.OldFullName;
                        pm.NewFullName = a.NewFullName;
                        pm.OldAddress = a.OldAddress;
                        pm.NewAddress = a.NewAddress;
                        pm.OldMobileNo = a.OldMobileNo;
                        pm.NewMobileNo = a.NewMobileNo;
                        pm.OldPinCode = a.OldPinCode;
                        pm.NewPinCode = a.NewPinCode;
                        userdetail.Add(pm);
                    }
                }
                else
                {
                    //int m1 = Int32.Parse(mobileno);
                    //int p1 = Int32.Parse(pincode);
                    var list = (from a in db.UserDetailLogs
                                join b in db.UserDetails on a.UserName equals b.UserName
                                 where(a.UserName.Contains(username) || a.ActionType.Contains(actiontype) ||
                                 ((a.NewFullName.Contains(fullname)) || (a.OldFullName.Contains(fullname))) || ((a.NewMobileNo == (mobileno)) || (a.OldMobileNo == (mobileno)))
                                 || ((a.OldPinCode == (pincode)) || (a.NewPinCode == (pincode))))
                                 select new
                                 {
                                 AuditId = a.AuditId,
                                 ActionType = a.ActionType,
                                 ActionDate = a.ActionDate,
                                 Gender = a.Gender,
                                 Email = a.EmailId,
                                 UserName = a.UserName,
                                 OldFullName = a.OldFullName,
                                 NewFullName = a.NewFullName,
                                 OldAddress = a.OldAddress,
                                 NewAddress = a.NewAddress,
                                 OldMobileNo = a.OldMobileNo,
                                 NewMobileNo = a.NewMobileNo,
                                 OldPinCode = a.OldPinCode,
                                 NewPinCode = a.NewPinCode
                                 });
                    foreach(var a in list)
                    {
                        UserDetailLog pm = new UserDetailLog();
                        pm.AuditId = a.AuditId;
                        pm.ActionType = a.ActionType;
                        pm.ActionDate = a.ActionDate;
                        pm.Gender = a.Gender;
                        pm.EmailId = a.Email;
                        pm.UserName = a.UserName;
                        pm.OldFullName = a.OldFullName;
                        pm.NewFullName = a.NewFullName;
                        pm.OldAddress = a.OldAddress;
                        pm.NewAddress = a.NewAddress;
                        pm.OldMobileNo = a.OldMobileNo;
                        pm.NewMobileNo = a.NewMobileNo;
                        pm.OldPinCode = a.OldPinCode;
                        pm.NewPinCode = a.NewPinCode;
                        userdetail.Add(pm);
                    }
                }
            }
            log.UserDetailList = userdetail; 
            return View(log);
        }

    }
}
