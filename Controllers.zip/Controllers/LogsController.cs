﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.Web.WebPages;
using System.IO;
using System.Data.SqlClient;
using System.Web.Security;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace BC.Controllers
{
    public class LogsController : Controller
    {
        public UserDBEntities db = new UserDBEntities();

        //GET: /Index/
        public ActionResult Index()
        {
            BookLog book = new BookLog();
            List<BookLog> booklog = new List<BookLog>();
            int id = Convert.ToInt32(Request["SearchType"]);
            string searchParameter = Request["ActionDate1"];
            DateTime searchParameter1 = DateTime.Now;
            DateTime searchParameter2 = DateTime.Now;
            if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
            {
                searchParameter1 = Convert.ToDateTime(Request["ActionDate2"]);
                searchParameter2 = Convert.ToDateTime(Request["ActionDate3"]);
            }
            //var list = null;
            if (id > 0)
            {
                if (!string.IsNullOrWhiteSpace(searchParameter) && !string.IsNullOrEmpty(searchParameter))
                {
                    if (id == 1)
                    {
                        if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
                        {
                            int c = 0;
                            int id1 = Int32.Parse(searchParameter);
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        where (a.ID == id1
                                        && a.ActionDate >= searchParameter1.Date && a.ActionDate <= searchParameter2.Date)
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                        else
                        {
                            //int c = 0;
                            int id1 = Int32.Parse(searchParameter);
                            var list = (from a in db.BooksLogs
                                        //join b in db.BookTables on a.ID equals b.ID
                                        where (a.ID == id1)// || a.ID == id1 )
                                        //&& a.ActionDate.CompareTo(searchParameter2)
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });

                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                    }
                    else if (id == 2)
                    {
                        if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        where (a.ActionType.Contains(searchParameter)
                                        && ((a.ActionDate >= (searchParameter1)) && (a.ActionDate <= (searchParameter2)))) 
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                        else
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        where a.ActionType.Contains(searchParameter)
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                    }
                    else if (id == 3)
                    {
                        if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        where (((a.OldName.Contains(searchParameter) || a.NewName.Contains(searchParameter))
                                        && ((a.ActionDate >= (searchParameter1)) && (a.ActionDate <= (searchParameter2)))))
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                        else
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        where (a.OldName.Contains(searchParameter) || a.NewName.Contains(searchParameter))
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                    }
                    else if (id == 4)
                    {
                        if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        join c in db.Categories on b.CategoryId equals c.CategoryId
                                        where (((c.CategoryName.Contains(searchParameter) || c.CategoryName.Contains(searchParameter))
                                        && ((a.ActionDate >= (searchParameter1)) && (a.ActionDate <= (searchParameter2)))))
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                        else
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        join c in db.Categories on b.CategoryId equals c.CategoryId
                                        where (c.CategoryName.Contains(searchParameter))
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                    }
                    else if (id == 5)
                    {
                        if (!string.IsNullOrEmpty(Request["ActionDate2"]) && !string.IsNullOrEmpty(Request["ActionDate3"]) && !string.IsNullOrWhiteSpace(Request["ActionDate2"]) && !string.IsNullOrWhiteSpace(Request["ActionDate3"]))
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        where (((a.NewAuthorName.Contains(searchParameter) || a.OldAuthorName.Contains(searchParameter))
                                        && ((a.ActionDate >= (searchParameter1)) && (a.ActionDate <= (searchParameter2)))))
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                        else
                        {
                            var list = (from a in db.BooksLogs
                                        join b in db.BookTables on a.ID equals b.ID
                                        where (a.NewAuthorName.Contains(searchParameter) || a.OldAuthorName.Contains(searchParameter))
                                        select new
                                        {
                                            AuditId = a.AuditId,
                                            ID = a.ID,
                                            ActionType = a.ActionType,
                                            ActionDate = a.ActionDate,
                                            OldName = a.OldName,
                                            NewName = a.NewName,
                                            OldAuthorName = a.OldAuthorName,
                                            NewAuthorName = a.NewAuthorName,
                                            OldCategoryId = a.OldCategoryId,
                                            NewCategoryId = a.NewCategoryId,
                                            OldBookDescription = a.OldBookDescription,
                                            NewBookDescription = a.NewBookDescription,
                                            OldQuantity = a.OldQuantity,
                                            NewQuantity = a.NewQuantity,
                                            OldAvailableQuantity = a.OldAvailableQuantity,
                                            NewAvailableQuantity = a.NewAvailableQuantity,
                                            OldIssueQuantity = a.OldIssueQuantity,
                                            NewIssueQuantity = a.NewIssueQuantity,
                                            OldBookCost = a.OldBookCost,
                                            NewBookCost = a.NewBookCost
                                        });
                            foreach (var a in list)
                            {
                                BookLog pm = new BookLog();
                                pm.AuditId = a.AuditId;
                                pm.ID = a.ID;
                                pm.ActionType = a.ActionType;
                                pm.ActionDate = a.ActionDate;
                                pm.OldName = a.OldName;
                                pm.NewName = a.NewName;
                                pm.OldAuthorName = a.OldAuthorName;
                                pm.NewAuthorName = a.NewAuthorName;
                                pm.OldCategoryName = db.Categories.Where(x => x.CategoryId == a.OldCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.NewCategoryName = db.Categories.Where(x => x.CategoryId == a.NewCategoryId).Select(x => x.CategoryName).FirstOrDefault();
                                pm.OldBookDescription = a.OldBookDescription;
                                pm.NewBookDescription = a.NewBookDescription;
                                pm.OldQuantity = a.OldQuantity;
                                pm.NewQuantity = a.NewQuantity;
                                pm.OldAvailableQuantity = a.OldAvailableQuantity;
                                pm.NewAvailableQuantity = a.NewAvailableQuantity;
                                pm.OldIssueQuantity = a.OldIssueQuantity;
                                pm.NewIssueQuantity = a.NewIssueQuantity;
                                pm.OldBookCost = a.OldBookCost;
                                pm.NewBookCost = a.NewBookCost;
                                booklog.Add(pm);
                            }
                        }
                    }
                }
            }

            book.BookLogList = booklog;
           
            return View(book);
        }
    }
}

        