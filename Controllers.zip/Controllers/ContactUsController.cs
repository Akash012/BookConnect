﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;

namespace BC.Controllers
{
    public class ContactUsController : Controller
    {
        private UserDBEntities db = new UserDBEntities();

        //
        // GET: /ContactUs/

        public ActionResult Index()
        {
            List<ContactU> contact = new List<ContactU>();
             contact = (from a in db.ContactUs 
                       orderby a.Id descending
                       select a).ToList();
            
            return View(contact);
        }

        //
        // GET: /ContactUs/Details/5

        public ActionResult Details(int id = 0)
        {
            ContactU contactu = db.ContactUs.Find(id);
            if (contactu == null)
            {
                return HttpNotFound();
            }
            return View(contactu);
        }

        ////
        //// GET: /ContactUs/Create

        //public ActionResult Create()
        //{
        //    return View();
        //}

        ////
        //// POST: /ContactUs/Create

        //[HttpPost]
        //public ActionResult Create(ContactU contactu)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.ContactUs.Add(contactu);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(contactu);
        //}

        ////
        //// GET: /ContactUs/Edit/5

        //public ActionResult Edit(int id = 0)
        //{
        //    ContactU contactu = db.ContactUs.Find(id);
        //    if (contactu == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(contactu);
        //}

        ////
        //// POST: /ContactUs/Edit/5

        //[HttpPost]
        //public ActionResult Edit(ContactU contactu)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(contactu).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(contactu);
        //}

        ////
        //// GET: /ContactUs/Delete/5

        //public ActionResult Delete(int id = 0)
        //{
        //    ContactU contactu = db.ContactUs.Find(id);
        //    if (contactu == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(contactu);
        //}

        ////
        //// POST: /ContactUs/Delete/5

        //[HttpPost, ActionName("Delete")]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    ContactU contactu = db.ContactUs.Find(id);
        //    db.ContactUs.Remove(contactu);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        //protected override void Dispose(bool disposing)
        //{
        //    db.Dispose();
        //    base.Dispose(disposing);
        //}
    }
}