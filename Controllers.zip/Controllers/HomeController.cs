﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.IO;
using System.Data;
using System.Web.Security;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Net.Configuration;


namespace BC.Controllers
{
    public class HomeController : Controller
    {
        UserDBEntities db = new UserDBEntities();
        //
        // GET: /Home/

        public ActionResult Index()
        {
            List<BookModel> bookmodel = new List<BookModel>();
            PopularTable popular = (from a in db.PopularTables
                                     select a).FirstOrDefault();
            List<BookTable> booktable = (from s in db.BookTables 
                                         where (s.StatusId == 1 || s.StatusId == 3)
                                         && (s.IssueQuantity >= popular.Number)
                                            select s).ToList();
            foreach (var d in booktable)
            {
                BookModel pm = new BookModel();
                pm.ID = d.ID;
                pm.Name = d.Name;
                pm.AuthorName = d.AuthorName;
                pm.ImageUrl = d.ImageUrl;
                pm.BookCost = d.BookCost;
                bookmodel.Add(pm);
            }

            var cnt = 0;
            var carttable = (from a in db.CartTables
                             join b in db.BookTables on a.ID equals b.ID
                             where a.UserName == User.Identity.Name
                             group new { a, b } by new { a.ID } into pg
                             let first = pg.FirstOrDefault()
                             let id = pg.Key.ID
                             let quantity = pg.Sum(s => s.a.NoOfQuantity)
                             let image = first.b
                             let name = first.b
                             let author = first.b
                             let cost = first.b
                             let availablequantity = first.b
                             let cartid = first.a.CartId
                             select new
                             {
                                 CartId = cartid,
                                 ID = id,
                                 NoOfQuantity = quantity,
                                 Image = image.ImageUrl,
                                 Name = name.Name,
                                 AuthorName = author.AuthorName,
                                 BookCost = cost.BookCost,
                                 AvailableQuantity = availablequantity.AvailableQuantity
                             });
            if (carttable.Count() > 0)
            {
                cnt = carttable.Sum(x => x.NoOfQuantity);
            }
            Session["count"] = cnt;

            return View(bookmodel);
        }
        
        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }
        
        [HttpPost]
        public ActionResult Contact(FormCollection fc)
        {
            ContactU contact = new ContactU();
            if (!string.IsNullOrEmpty(fc["Name"]) && !string.IsNullOrWhiteSpace(fc["Name"]) &&
             !string.IsNullOrEmpty(fc["EmailId"]) && !string.IsNullOrWhiteSpace(fc["EmailId"]) &&
             !string.IsNullOrEmpty(fc["Message"]) && !string.IsNullOrWhiteSpace(fc["Message"]))
            {
                contact.Name = fc["Name"];
                contact.EmailId = fc["EmailId"];
                contact.Subject = fc["Subject"];
                contact.Message = fc["Message"];
                contact.DateTime = System.DateTime.Now;
                db.ContactUs.Add(contact);
                db.SaveChanges();
            }
            else
            {
                ModelState.AddModelError("", "");
                return View();
            }
            return RedirectToAction("Index","Home");
        }

        

        public ActionResult Cart()
        {
            CartModel cart = new CartModel(); 
            List<CartModel> Items = new List<CartModel>();
            List<BookModel> bookmodel = new List<BookModel>();
            List<SelectListItem> qty = new List<SelectListItem>();
            
            var cnt = 0;
            var carttable = (from a in db.CartTables
                                         join b in db.BookTables on a.ID equals b.ID
                                         where a.UserName == User.Identity.Name
                                        group new { a , b} by new { a.ID} into pg
                                          let first = pg.FirstOrDefault()
                                         let id = pg.Key.ID
                                         let quantity = pg.Sum(s => s.a.NoOfQuantity)
                                         let image = first.b
                                         let name = first.b
                                         let author = first.b
                                         let cost = first.b
                                         let availablequantity = first.b
                                         let cartid = first.a.CartId
                                         select new
                                          {
                                              CartId = cartid,
                                              ID = id,
                                              NoOfQuantity = quantity,
                                              Image = image.ImageUrl,
                                              Name = name.Name,
                                              AuthorName = author.AuthorName,
                                              BookCost = cost.BookCost,
                                              AvailableQuantity = availablequantity.AvailableQuantity
                                          });
            if (carttable.Count() > 0)
            {
                cnt = carttable.Sum(x => x.NoOfQuantity);
            }
            Session["count"] = cnt;
            foreach (var z in carttable)
            {
                CartModel a = new CartModel();
                a.CartId = Convert.ToInt32(z.CartId);
                a.ID = z.ID;
                a.NoOfQuantity = z.NoOfQuantity;
                a.ImageUrl = z.Image;
                a.Name = z.Name;
                a.AuthorName = z.AuthorName;
                a.BookCost = z.BookCost;
                a.AvailableQuantity = z.AvailableQuantity;
                a.TotalCost = (z.NoOfQuantity * z.BookCost);
                List<SelectListItem> j = new List<SelectListItem>();
                qty = j;
                for (int i = 1; i <= a.AvailableQuantity; i++)
                {
                    SelectListItem pm = new SelectListItem();
                    pm.Text = i.ToString();
                    pm.Value = i.ToString();
                    if (a.NoOfQuantity == i)
                    {
                        pm.Selected = true;
                    }
                    qty.Add(pm);
                }
                a.AvailableQuantityList = qty;
                Items.Add(a);

            }
           
          return View(Items.ToList());
            
        }

        
        public ActionResult Delete(int id)
        {
            
            CartTable carttable = db.CartTables.Find(id);
             db.CartTables.Remove(carttable);
            db.SaveChanges();
            return RedirectToAction("Cart");
        }

        [HttpPost]
        public ActionResult CartEdit(CartTable carttable, FormCollection c, int id = 0)
        {
            carttable = (from a in db.CartTables
                         where id == a.ID && a.UserName == User.Identity.Name
                         select a).FirstOrDefault();
            carttable.NoOfQuantity = Convert.ToInt32(c["item.NoOfQuantity"]);
            if (ModelState.IsValid)
            {
                db.Entry(carttable).State = EntityState.Modified;
                db.SaveChanges();
            }
            return RedirectToAction("Cart","Home");
        }

        public ActionResult OrderConfirm(int id = 0)
        {
            OrderConfirm orderconfirm = new Models.OrderConfirm();
            List<OrderConfirm> orderlist = new List<Models.OrderConfirm>();
            if (id == 0)
            {
                id = Convert.ToInt32(Session["ID"]);
                var add = (from a in db.UserDetails
                           where id == a.Id
                           select a).FirstOrDefault();
                HttpContext.Session.Add("Userdetail", add);

                var ord = (from e in db.OrderTables
                           where e.UserName == User.Identity.Name
                           select e).ToList();
                if (ord.Count == 0)
                {
                    var cart = (from z in db.CartTables
                                join q in db.BookTables on z.ID equals q.ID
                                where z.UserName == User.Identity.Name
                                 && q.AvailableQuantity > 0
                                select new
                                {
                                    CartId = z.CartId,
                                    ID = z.ID,
                                    BookName = q.Name,
                                    NoOfQuantity = z.NoOfQuantity,
                                    BookCost = q.BookCost,
                                    AuthorName = q.AuthorName,
                                }).ToList();
                    var car = cart.Count();
                    HttpContext.Session.Add("Cartdetail", cart);
                    foreach (var c in cart)
                    {
                        OrderConfirm pm = new Models.OrderConfirm();
                        pm.CartId = c.CartId;
                        pm.ID = c.ID;
                        pm.BookName = c.BookName;
                        pm.NoOfQuantity = c.NoOfQuantity;
                        pm.BookCost = c.BookCost;
                        pm.AuthorName = c.AuthorName;
                        pm.TotalCost = (c.NoOfQuantity * c.BookCost);
                        orderlist.Add(pm);
                    }
                    if (car == 0)
                    {
                        return RedirectToAction("Index", "Home");
                    }

                }
                else
                {
                    var order = (from b in db.OrderTables
                                 join c in db.BookTables on b.ID equals c.ID
                                 where b.UserName == User.Identity.Name
                                 select new
                                 {
                                     orderId = b.OrderId,
                                     BookId = b.ID,
                                     BookName = c.Name,
                                     NoOfQuantity = b.NoOfQuantity,
                                     BookCost = c.BookCost,
                                     AuthorName = c.AuthorName
                                 }).ToList();
                    var od = order.Count();
                    HttpContext.Session.Add("Orderdetail", order);
                    foreach (var or in order)
                    {
                        OrderConfirm am = new Models.OrderConfirm();
                        am.OrderId = or.orderId;
                        am.ID = or.BookId;
                        am.BookName = or.BookName;
                        am.NoOfQuantity = or.NoOfQuantity;
                        am.BookCost = or.BookCost;
                        am.AuthorName = or.AuthorName;
                        am.TotalCost = (or.NoOfQuantity * or.BookCost);
                        orderlist.Add(am);
                    }
                    if (od == 0)
                    {
                        return RedirectToAction("Index", "Home");
                    }
                }
            }
            else
            {
                Session["ID"] = id;
                var add = (from a in db.UserDetails
                           where id == a.Id
                           select a).FirstOrDefault();
                HttpContext.Session.Add("Userdetail", add);

                var ord = (from e in db.OrderTables
                           where e.UserName == User.Identity.Name
                           select e).ToList();
                if (ord.Count == 0)
                {
                    var carts = (from z in db.CartTables
                                join q in db.BookTables on z.ID equals q.ID
                                where z.UserName == User.Identity.Name
                                 && q.AvailableQuantity > 0
                                select new
                                {
                                    CartId = z.CartId,
                                    ID = z.ID,
                                    BookName = q.Name,
                                    NoOfQuantity = z.NoOfQuantity,
                                    BookCost = q.BookCost,
                                    AuthorName = q.AuthorName,
                                }).ToList();
                    HttpContext.Session.Add("Cartdetail", carts);
                    foreach (var cr in carts)
                    {
                        OrderConfirm zm = new Models.OrderConfirm();
                        zm.CartId = cr.CartId;
                        zm.ID = cr.ID;
                        zm.BookName = cr.BookName;
                        zm.NoOfQuantity = cr.NoOfQuantity;
                        zm.BookCost = cr.BookCost;
                        zm.AuthorName = cr.AuthorName;
                        zm.TotalCost = (cr.NoOfQuantity * cr.BookCost);
                        orderlist.Add(zm);
                    }
                }
                else
                {
                    var ordr = (from b in db.OrderTables
                                 join c in db.BookTables on b.ID equals c.ID
                                 where b.UserName == User.Identity.Name
                                 select new
                                 {
                                     orderId = b.OrderId,
                                     BookId = b.ID,
                                     BookName = c.Name,
                                     NoOfQuantity = b.NoOfQuantity,
                                     BookCost = c.BookCost,
                                     AuthorName = c.AuthorName
                                 }).ToList();
                    HttpContext.Session.Add("Orderdetail", ordr);
                    foreach (var o in ordr)
                    {
                        OrderConfirm qm = new Models.OrderConfirm();
                        qm.OrderId = o.orderId;
                        qm.ID = o.BookId;
                        qm.BookName = o.BookName;
                        qm.NoOfQuantity = o.NoOfQuantity;
                        qm.BookCost = o.BookCost;
                        qm.AuthorName = o.AuthorName;
                        qm.TotalCost = (o.NoOfQuantity * o.BookCost);
                        orderlist.Add(qm);
                    }
                }

            }
            HttpContext.Session.Add("Orderdetail", orderlist);
            return View(orderlist);
        }
    
        public ActionResult Trasaction()
        {
            TransactionTable transaction = new TransactionTable();
            UserDetail userdetail = Session["Userdetail"] as UserDetail;
            transaction.AddId = userdetail.Id;
            var ord = (from e in db.OrderTables
                       where e.UserName == User.Identity.Name
                       select e).ToList();
            if (ord.Count == 0)
            {
                var carttable = (from a in db.CartTables
                                 join b in db.BookTables on a.ID equals b.ID
                                 where a.UserName == User.Identity.Name
                                     && b.AvailableQuantity > 0
                                 select new
                                 {
                                     CartId = a.CartId,
                                     BookId = b.ID,
                                     NoOfQuantity = a.NoOfQuantity,
                                     BookCost = b.BookCost,
                                     TotalCost = (a.NoOfQuantity * b.BookCost)
                                 }).ToList();

                foreach (var c in carttable)
                {
                    transaction.CartId = c.CartId;
                    transaction.TotalCost = c.TotalCost;
                    transaction.NoOfQuantity = c.NoOfQuantity;
                    transaction.BookId = c.BookId;
                    transaction.StatusId = 1;
                    db.TransactionTables.Add(transaction);
                    db.SaveChanges();
                }
                
                HttpContext.Session.Remove("Userdetail");
                return RedirectToAction("DeductionCart","BookManage");
            }
            else
            {
                var ordertable = (from q in db.OrderTables
                                  join w in db.BookTables on q.ID equals w.ID
                                  where q.UserName == User.Identity.Name
                                    && w.AvailableQuantity > 0
                                  select new
                                  {
                                      OrderId = q.OrderId,
                                      BookId = w.ID,
                                      NoOfQuantity = q.NoOfQuantity,
                                      BookCost = w.BookCost,
                                      TotalCost = (q.NoOfQuantity * w.BookCost)
                                  }).FirstOrDefault();
                transaction.OrderId = ordertable.OrderId;
                transaction.TotalCost = ordertable.TotalCost;
                transaction.NoOfQuantity = ordertable.NoOfQuantity;
                transaction.BookId = ordertable.BookId;
                transaction.StatusId = 1;
                db.TransactionTables.Add(transaction);
                db.SaveChanges();
                HttpContext.Session.Add("dedu", transaction);
                
                HttpContext.Session.Remove("Userdetail");
                return RedirectToAction("DeductionOrder","BookManage");
            }
            
        }

        public ActionResult CartDelete()
        {
           var carttable = (from a in db.CartTables
                             join b in db.BookTables on a.ID equals b.ID
                             where a.UserName == User.Identity.Name
                             && b.AvailableQuantity > 0
                             select a).ToList();
           HttpContext.Session.Add("cartid", carttable);
            foreach (var c in carttable)
            {
            db.CartTables.Remove(c);
            db.SaveChanges();
            }
            var cnt = 0;
            var carttables = (from a in db.CartTables
                             join b in db.BookTables on a.ID equals b.ID
                             where a.UserName == User.Identity.Name
                             group new { a, b } by new { a.ID } into pg
                             let first = pg.FirstOrDefault()
                             let id = pg.Key.ID
                             let quantity = pg.Sum(s => s.a.NoOfQuantity)
                             let image = first.b
                             let name = first.b
                             let author = first.b
                             let cost = first.b
                             let availablequantity = first.b
                             let cartid = first.a.CartId
                             select new
                             {
                                 CartId = cartid,
                                 ID = id,
                                 NoOfQuantity = quantity,
                                 Image = image.ImageUrl,
                                 Name = name.Name,
                                 AuthorName = author.AuthorName,
                                 BookCost = cost.BookCost,
                                 AvailableQuantity = availablequantity.AvailableQuantity
                             });
            if (carttables.Count() > 0)
            {
                cnt = carttables.Sum(x => x.NoOfQuantity);
            }
            Session["count"] = cnt;
            return RedirectToAction("SendMailConfirm");
        }

        public ActionResult OrderDelete()
        {
            OrderTable ordertable = (from a in db.OrderTables
                                     where a.UserName == User.Identity.Name
                                     select a).FirstOrDefault();
            HttpContext.Session.Add("orderid", ordertable);
            db.OrderTables.Remove(ordertable);
            db.SaveChanges();
            var cnt = 0;
            var carttable = (from a in db.CartTables
                             join b in db.BookTables on a.ID equals b.ID
                             where a.UserName == User.Identity.Name
                             group new { a, b } by new { a.ID } into pg
                             let first = pg.FirstOrDefault()
                             let id = pg.Key.ID
                             let quantity = pg.Sum(s => s.a.NoOfQuantity)
                             let image = first.b
                             let name = first.b
                             let author = first.b
                             let cost = first.b
                             let availablequantity = first.b
                             let cartid = first.a.CartId
                             select new
                             {
                                 CartId = cartid,
                                 ID = id,
                                 NoOfQuantity = quantity,
                                 Image = image.ImageUrl,
                                 Name = name.Name,
                                 AuthorName = author.AuthorName,
                                 BookCost = cost.BookCost,
                                 AvailableQuantity = availablequantity.AvailableQuantity
                             });
            if (carttable.Count() > 0)
            {
                cnt = carttable.Sum(x => x.NoOfQuantity);
            }
            Session["count"] = cnt;

            return RedirectToAction("SendMailConfirm");
        }
    
        
        public ActionResult TransactionManage()
        {
            List<TransactionModel> tranmodel = new List<TransactionModel>();
            
             var table = (from a in db.TransactionTables
                         join b in db.UserDetails on a.AddId equals b.Id
                         join c in db.BookTables on a.BookId equals c.ID
                         join d in db.DeliveryStatusTables on a.StatusId equals d.Id
                         where a.StatusId == 1 && b.UserName == User.Identity.Name
                         select new
                         {
                             Id = a.TransactionId,
                           NoOfQuantity = a.NoOfQuantity,
                           TotalCost = a.TotalCost,
                           StatusName = d.DeliveryStatus,
                           ImageUrl = c.ImageUrl,
                           BookName = c.Name,
                           AuthorName = c.AuthorName,
                           BookCost = c.BookCost,
                           FullName = b.FullName
                         }).ToList();
            foreach(var e in table)
            {
                TransactionModel tm = new TransactionModel();
                tm.TransactionId = e.Id;
                tm.NoOfQuantity = e.NoOfQuantity;
                tm.TotalCost = e.TotalCost;
                tm.BookCost = e.BookCost;
                tm.AuthorName = e.AuthorName;
                tm.Name = e.BookName;
                tm.ImageUrl = e.ImageUrl;
                tm.FullName = e.FullName;
                tm.StatusName = e.StatusName;
                tranmodel.Add(tm);
            }
                  return View(tranmodel.ToList());
            }
           
        public ActionResult TransactionDelivered()
            {
                List<TransactionModel> tranmodel = new List<TransactionModel>();
            var tablelist = (from e in db.TransactionTables
                         join f in db.UserDetails on e.AddId equals f.Id
                         join g in db.BookTables on e.BookId equals g.ID
                         join h in db.DeliveryStatusTables on e.StatusId equals h.Id
                         where e.StatusId == 2 && f.UserName == User.Identity.Name
                         select new
                         {
                           NoOfQuantity = e.NoOfQuantity,
                           TotalCost = e.TotalCost,
                           StatusName = h.DeliveryStatus,
                           ImageUrl = g.ImageUrl,
                           BookName = g.Name,
                           AuthorName = g.AuthorName,
                           BookCost = g.BookCost,
                           FullName = f.FullName
                         }).ToList();
                foreach(var t in tablelist)
            {
                TransactionModel tm = new TransactionModel();
                tm.NoOfQuantity = t.NoOfQuantity;
                tm.TotalCost = t.TotalCost;
                tm.BookCost = t.BookCost;
                tm.AuthorName = t.AuthorName;
                tm.Name = t.BookName;
                tm.ImageUrl = t.ImageUrl;
                tm.FullName = t.FullName;
                tm.StatusName = t.StatusName;
                tranmodel.Add(tm);
            }
            
            return View(tranmodel.ToList());
    }

        public ActionResult TransactionDelete(int id)
        {

            TransactionTable trantable = db.TransactionTables.Find(id);
            HttpContext.Session.Add("transadd",trantable);
            db.TransactionTables.Remove(trantable);
            db.SaveChanges();
            return RedirectToAction("AddTrans");
        }

        public ActionResult AddTrans()
        {
            TransactionTable transtable = Session["transadd"] as TransactionTable;
            BookTable book = new BookTable();
            BooksLog booklog = new BooksLog();
            book = (from a in db.BookTables
                    where transtable.BookId == a.ID
                    select a).FirstOrDefault();
            int AQ = book.AvailableQuantity;
            int AA = book.IssueQuantity;
            HttpContext.Session.Add("olddata", book);
            BookTable books = Session["olddata"] as BookTable;
            book.IssueQuantity = (AA - transtable.NoOfQuantity);
            book.AvailableQuantity = (AQ + transtable.NoOfQuantity);
            if (ModelState.IsValid)
            {
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
            }
            booklog.ID = book.ID;
            booklog.ActionType = "Edited";
            booklog.ActionDate = System.DateTime.Now;
            booklog.NewName = "NAN";
            booklog.OldName = books.Name;
            booklog.NewAuthorName = "NAN";
            booklog.OldAuthorName = books.AuthorName;
            booklog.OldCategoryId = books.CategoryId;
            booklog.NewBookDescription = "NAN";
            booklog.OldBookDescription = books.BookDescription;
            booklog.OldQuantity = books.Quantity;
            booklog.OldAvailableQuantity = books.AvailableQuantity;
            booklog.NewAvailableQuantity = book.AvailableQuantity;
            booklog.OldIssueQuantity = books.IssueQuantity;
            booklog.NewIssueQuantity = book.IssueQuantity;
            booklog.OldBookCost = books.BookCost;
            db.BooksLogs.Add(booklog);
            if (ModelState.IsValid)
            {
                db.Entry(booklog).State = EntityState.Added;
                db.SaveChanges();
            }
            HttpContext.Session.Remove("transadd");
            return RedirectToAction("TransactionManage");
        }

       
        public ActionResult SendMailConfirm()
        {
            var email = (from a in db.UserDetails
                            where a.UserName == User.Identity.Name
                            select a.EmailId).FirstOrDefault();
            string user = (from a in db.UserDetails
                           where a.UserName == User.Identity.Name
                           select a.FullName).FirstOrDefault();
            OrderTable order = Session["orderid"] as OrderTable;
            List<CartTable> cart = Session["cartid"] as List<CartTable>;
            List<TransactionModel> tranmodel = new List<TransactionModel>();
            TransactionModel trans = new TransactionModel();
            if (order == null)
            {
                List<TransactionModel> transac = new List<TransactionModel>();
                foreach (var z in cart)
                {
                    var tra = (from a in db.TransactionTables
                               join b in db.UserDetails on a.AddId equals b.Id
                               join c in db.BookTables on a.BookId equals c.ID
                               where a.StatusId == 1 && b.UserName == User.Identity.Name
                              && a.CartId == z.CartId
                               select new
                               {
                                   Transaction = a.TransactionId,
                                   BookName = c.Name,
                                   NoOfQuantity = a.NoOfQuantity,
                                   TotalCost = a.TotalCost,
                                   BookCost = c.BookCost,

                               }).Distinct().ToList();
                    
                    foreach (var s in tra)
                    {
                        TransactionModel pm = new TransactionModel();
                        pm.TransactionId = s.Transaction;
                        pm.Name = s.BookName;
                        pm.NoOfQuantity = s.NoOfQuantity;
                        pm.TotalCost = s.TotalCost;
                        pm.BookCost = s.BookCost;
                        transac.Add(pm);
                    }

                    trans.TransactionList = transac;
                }
                

                //trans.Transaction =  new List<SelectListItem>;
                using (MailMessage mm = new MailMessage())
                {
                    string From = "bconnect2018@gmail.com";
                    mm.From = new MailAddress(From,"BookConnect");
                    mm.To.Add(email.ToString());
                    mm.Subject = "Order Placed Confirmation";
                    mm.IsBodyHtml = true;
                    mm.Body = "Dear Customer" + user + "Your Order is Confirmed.<br><HTML><body><Table border=1px solid><tr><th>Order Id</th><th>Book Name</th><th>No. Of Quantity</th><th>Price</th></tr>";
                    foreach (var item in trans.TransactionList)
                    {
                        mm.Body += "<tr><td>"+item.TransactionId+"</td><td>" + item.Name + "</td><td>" + item.NoOfQuantity + "</td><td>" + item.TotalCost + "</td></tr>";
                    }
                    mm.Body += "</table></body></html>";
                    mm.Body += "<b>Final Total</b><div>" + transac.Sum(x => x.TotalCost) + "</div>";
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    string UserName = "bconnect2018@gmail.com";
                    string Password = "password2018";
                    NetworkCredential network = new NetworkCredential(UserName, Password);
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = network;
                    smtp.Port = 587;
                    smtp.Send(mm);
                }
            }
            else
            {
                var tran = (from a in db.TransactionTables
                            join b in db.UserDetails on a.AddId equals b.Id
                            join c in db.BookTables on a.BookId equals c.ID
                            where a.StatusId == 1 && b.UserName == User.Identity.Name
                            && a.OrderId == order.OrderId
                            select new
                            {
                                Transaction = a.TransactionId,
                                BookName = c.Name,
                                NoOfQuantity = a.NoOfQuantity,
                                TotalCost = a.TotalCost,
                                BookCost = c.BookCost,

                            }).ToList();
                //SmtpSection secobj = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");
                using (MailMessage mm = new MailMessage())
                {
                    string From = "bconnect2018@gmail.com";
                    mm.From = new MailAddress(From);
                    mm.To.Add(email.ToString());
                    mm.Subject = "Order Placed Confirmation";
                    mm.IsBodyHtml = true;
                    mm.Body = "Dear Customer" + user + "Your Order is Confirmed.<br><HTML border=1><body><Table><tr><th>Book Name</th><th>No. Of Quantity</th><th>Price</th></tr>";
                    foreach (var item in tran)
                    {
                        mm.Body += "<tr><td>"+item.Transaction+"</td><td>" + item.BookName + "</td><td>" + item.NoOfQuantity + "</td><td>" + item.TotalCost + "</td></tr>";
                    }
                    mm.Body += "</table></body></html>";
                    mm.Body += "<b>Final Total</b><div>" + tran.Sum(x => x.TotalCost) + "</div>";
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    string UserName = "bconnect2018@gmail.com";
                    string Password = "password2018";
                    NetworkCredential network = new NetworkCredential(UserName, Password);
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = network;
                    smtp.Port = 587;
                    smtp.Send(mm);
                }
            }
            
            
            return RedirectToAction("Index");
        }


        public ActionResult CartConfirmDelete(int id)
        {

            CartTable carttable = db.CartTables.Find(id);
            db.CartTables.Remove(carttable);
            db.SaveChanges();
            return RedirectToAction("OrderConfirm");
        }

        public ActionResult OrderConfirmDelete(int id)
        {

            OrderTable ordertable = db.OrderTables.Find(id);
            db.OrderTables.Remove(ordertable);
            db.SaveChanges();
            return RedirectToAction("OrderConfirm");
        }
        
        
         public ActionResult NetBank(NetBank nb, FormCollection fc)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("BankForm", "Home");
            }
            else
            {
                ModelState.AddModelError("", "");
            }
                return View();
        }

        public ActionResult BankForm()
        {
            return View();
        }

        [HttpPost]
        public ActionResult BankForm(NetForm np,FormCollection fc)
        {
            if(!string.IsNullOrEmpty(fc["TransactionId"]) && !string.IsNullOrWhiteSpace(fc["TransactionId"])
            && !string.IsNullOrWhiteSpace(fc["Password"]) && !string.IsNullOrEmpty(fc["Password"]))
            {
            string TransactionId = fc["TransactionId"];
            string Password = fc["Password"];
            if(ModelState.IsValid)
            {
            return RedirectToAction("Trasaction","Home");
            }
            }
            ModelState.AddModelError("","");
           return View();
        }
        
        public ActionResult Card()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Card( CardDetail card, FormCollection fc)
        {
            if(!string.IsNullOrEmpty(fc["CardNo"]) && !string.IsNullOrWhiteSpace(fc["CardNo"]) &&
                !string.IsNullOrEmpty(fc["CVV"]) && !string.IsNullOrWhiteSpace(fc["CVV"]) &&
                !string.IsNullOrEmpty(fc["CardNo"]) && !string.IsNullOrWhiteSpace(fc["CardNo"]) &&
                !string.IsNullOrEmpty(fc["Month"]) && !string.IsNullOrWhiteSpace(fc["Month"]) &&
                !string.IsNullOrEmpty (fc["Year"]) && !string.IsNullOrWhiteSpace(fc["Year"]))
            {
            string CardName = fc["CardName"];
            string CardNo = fc["CardNo"];
            string Month = fc["Month"];
            string Year = fc["Year"];
            string CVV = fc["CVV"];
            if (ModelState.IsValid)
            {
                return RedirectToAction("Trasaction", "Home");
            }
            else
            {
                ModelState.AddModelError("","");
                return View();
            }
            }
           return View();
        }
    }
}
