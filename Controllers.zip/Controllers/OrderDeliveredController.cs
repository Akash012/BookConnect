﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using PagedList;

namespace BC.Controllers
{
    public class OrderDeliveredController : Controller
    {
        private UserDBEntities db = new UserDBEntities();

        //
        // GET: /OrderDelivered/

        public ActionResult Index(int? page)
        {
            List<TransactionModel> tranmodel = new List<TransactionModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            
            var tran = (from a in db.TransactionTables
                        join b in db.UserDetails on a.AddId equals b.Id
                        join c in db.BookTables on a.BookId equals c.ID
                        where a.StatusId == 2
                        select new
                        {
                            TranID = a.TransactionId,
                            FullName = b.FullName,
                            Add = b.Address,
                            PinCode = b.PinCode,
                            Mobile = b.MobileNo,
                            BookName = c.Name,
                            NoOfQuantity = a.NoOfQuantity,
                            TotalCost = (a.NoOfQuantity * c.BookCost),
                            StatusId = a.StatusId
                        }).ToList();
            foreach (var list in tran)
            {
                TransactionModel tm = new TransactionModel();
                tm.TransactionId = list.TranID;
                tm.FullName = list.FullName;
                tm.Address = list.Add;
                tm.PinCode = list.PinCode;
                tm.Mobile = list.Mobile;
                tm.Name = list.BookName;
                tm.NoOfQuantity = list.NoOfQuantity;
                tm.TotalCost = list.TotalCost;
                tm.StatusName = db.DeliveryStatusTables.Where(x => x.Id == list.StatusId).Select(x => x.DeliveryStatus).FirstOrDefault();
                tranmodel.Add(tm);
            }
            return View(tranmodel.ToPagedList(pageNumber, pageSize));
        }

        //
        // GET: /OrderDelivered/Details/5

        public ActionResult Details(TransactionModel tranmodel,int id = 0)
        {
            //TransactionTable transactiontable = db.TransactionTables.Find(id);
            var transactiontable = (from a in db.TransactionTables
                                    join b in db.UserDetails on a.AddId equals b.Id
                                    join c in db.BookTables on a.BookId equals c.ID
                                    where a.TransactionId == id
                                    select new
                                    {
                                        TranID = a.TransactionId,
                                        AddID = a.AddId,
                                        BookID = a.BookId,
                                        FullName = b.FullName,
                                        Add = b.Address,
                                        PinCode = b.PinCode,
                                        Mobile = b.MobileNo,
                                        BookName = c.Name,
                                        NoOfQuantity = a.NoOfQuantity,
                                        TotalCost = (a.NoOfQuantity * c.BookCost),
                                        StatusId = a.StatusId
                                    }).FirstOrDefault();

            if (transactiontable == null)
            {
                return HttpNotFound();
            }
            else
            {
                List<SelectListItem> deliverystatus = new List<SelectListItem>();

                var list = (from data in db.DeliveryStatusTables select data).ToList();

                foreach (var d in list)
                {
                    SelectListItem pm = new SelectListItem();

                    pm.Value = d.Id.ToString();
                    pm.Text = d.DeliveryStatus;
                    if (pm.Value == transactiontable.StatusId.ToString())
                    {
                        pm.Selected = true;
                    }
                    deliverystatus.Add(pm);
                }
                tranmodel.AddId = transactiontable.AddID;
                tranmodel.BookId = transactiontable.BookID;
                tranmodel.TransactionId = transactiontable.TranID;
                tranmodel.DeliveryStatus = deliverystatus;
                tranmodel.StatusName = db.DeliveryStatusTables.Where(x => (x.Id == transactiontable.StatusId)).Select(x => x.DeliveryStatus).FirstOrDefault();
                tranmodel.FullName = transactiontable.FullName;
                tranmodel.Address = transactiontable.Add;
                tranmodel.PinCode = transactiontable.PinCode;
                tranmodel.Mobile = transactiontable.Mobile;
                tranmodel.Name = transactiontable.BookName;
                tranmodel.NoOfQuantity = transactiontable.NoOfQuantity;
                tranmodel.TotalCost = transactiontable.TotalCost;
            }
            return View(tranmodel);
        }

        ////
        //// GET: /OrderDelivered/Create

        //public ActionResult Create()
        //{
        //    return View();
        //}

        ////
        //// POST: /OrderDelivered/Create

        //[HttpPost]
        //public ActionResult Create(TransactionTable transactiontable)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.TransactionTables.Add(transactiontable);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(transactiontable);
        //}

        ////
        //// GET: /OrderDelivered/Edit/5

        //public ActionResult Edit(int id = 0)
        //{
        //    TransactionTable transactiontable = db.TransactionTables.Find(id);
        //    if (transactiontable == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(transactiontable);
        //}

        ////
        //// POST: /OrderDelivered/Edit/5

        //[HttpPost]
        //public ActionResult Edit(TransactionTable transactiontable)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(transactiontable).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(transactiontable);
        //}

        ////
        //// GET: /OrderDelivered/Delete/5

        //public ActionResult Delete(int id = 0)
        //{
        //    TransactionTable transactiontable = db.TransactionTables.Find(id);
        //    if (transactiontable == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(transactiontable);
        //}

        ////
        //// POST: /OrderDelivered/Delete/5

        //[HttpPost, ActionName("Delete")]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    TransactionTable transactiontable = db.TransactionTables.Find(id);
        //    db.TransactionTables.Remove(transactiontable);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        //Get
        public ActionResult Search()
        {
            var tran = db.TransactionTables.Where(x => (x.StatusId == 1)).ToList();
            return View(tran);
        }

        //POST
        [HttpPost]
        public ActionResult Search(List<TransactionModel> model, int? page)
        {
            List<TransactionModel> tranmodel = new List<TransactionModel>();
            //List<TransactionTable> trantable = new List<TransactionTable>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            string filter = Request["search"];
            if (!string.IsNullOrEmpty(filter) && !string.IsNullOrWhiteSpace(filter))
            {
                var tran = (from a in db.TransactionTables
                            join b in db.UserDetails on a.AddId equals b.Id
                            join c in db.BookTables on a.BookId equals c.ID
                            where (((b.FullName.Contains(filter))
                            || (b.PinCode.Contains(filter)) || (b.MobileNo.Contains(filter))
                            || (c.Name.Contains(filter))) && (a.StatusId == 2))
                            select new
                            {
                                TranID = a.TransactionId,
                                FullName = b.FullName,
                                Add = b.Address,
                                PinCode = b.PinCode,
                                Mobile = b.MobileNo,
                                BookName = c.Name,
                                NoOfQuantity = a.NoOfQuantity,
                                TotalCost = (a.NoOfQuantity * c.BookCost),
                                StatusId = a.StatusId
                            }).ToList();
                foreach (var list in tran)
                {
                    TransactionModel tm = new TransactionModel();
                    tm.TransactionId = list.TranID;
                    tm.FullName = list.FullName;
                    tm.Address = list.Add;
                    tm.PinCode = list.PinCode;
                    tm.Mobile = list.Mobile;
                    tm.Name = list.BookName;
                    tm.NoOfQuantity = list.NoOfQuantity;
                    tm.TotalCost = list.TotalCost;
                    tm.StatusName = db.DeliveryStatusTables.Where(x => x.Id == list.StatusId).Select(x => x.DeliveryStatus).FirstOrDefault();
                    tranmodel.Add(tm);
                }

            }
            //model.TransactionList = trantable;
            return View(tranmodel.ToPagedList(pageNumber, pageSize));
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}