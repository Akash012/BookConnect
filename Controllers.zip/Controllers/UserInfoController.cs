﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using PagedList;

namespace BC.Controllers
{
    public class UserInfoController : Controller
    {
        UserDBEntities db = new UserDBEntities();
        //
        // GET: /UserInfo/

        public ActionResult Index(int? page)
        {
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            List<UserModel> model = new List<UserModel>();
            var user = (from a in db.UserDetails
                        join b in db.aspnet_Users on a.UserName equals b.UserName
                        join c in db.aspnet_Membership on b.UserId equals c.UserId
                        select new
                        {
                            FullName = a.FullName,
                            UserName = b.UserName,
                            Email = c.Email,
                            Gender = a.Gender,
                            Address = a.Address,
                            DOB = a.DOB,
                            Mobile = a.MobileNo,
                            Pincode = a.PinCode
                        }).ToList();
            foreach (var list in user)
            {
                UserModel pm = new UserModel();
                pm.FullName = list.FullName;
                pm.UserName = list.UserName;
                pm.Email = list.Email;
                pm.Gender = list.Gender;
                pm.Address = list.Address;
                pm.DOB = list.DOB;
                pm.MobileNo = list.Mobile;
                pm.PinCode = list.Pincode;
                model.Add(pm);
            }
            return View(model.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult Search()
        {
            var usr = db.UserDetails.Where(x => (x.StatusId == 1) || (x.StatusId == 3)).ToList();
            return View(usr);
        }

        [HttpPost]
        public ActionResult Search(int? page)
        {
            List<UserModel> model = new List<UserModel>();
            if (Request.HttpMethod != "GET")
            {
                page = 1;
            }
            int pageSize = 10;
            int pageNumber = (page ?? 1);
            string filter = Request["search"];
            if (!string.IsNullOrEmpty(filter) && !string.IsNullOrWhiteSpace(filter))
            {
                var user = (from a in db.UserDetails
                            where (((a.UserName.Contains(filter)) || (a.FullName.Contains(filter))
                            || (a.EmailId.Contains(filter)) || (a.Gender.Contains(filter)) ||
                            (a.PinCode.Contains(filter)) || (a.MobileNo.Contains(filter))
                            ) && ((a.StatusId == 1) || (a.StatusId == 3)))
                            select a).ToList();
                foreach (var list in user)
                {
                    UserModel pm = new UserModel();
                    pm.FullName = list.FullName;
                    pm.UserName = list.UserName;
                    pm.Email = list.EmailId;
                    pm.Gender = list.Gender;
                    pm.Address = list.Address;
                    pm.DOB = list.DOB;
                    pm.MobileNo = list.MobileNo;
                    pm.PinCode = list.PinCode;
                    model.Add(pm);
                }
               
            }
            return View(model.ToPagedList(pageNumber, pageSize));
        }


    }
}
